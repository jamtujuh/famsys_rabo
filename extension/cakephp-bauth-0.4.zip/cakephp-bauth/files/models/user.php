<?php
//As you can see here there are no changes required in the user model
class User extends AppModel {	
	var $name = 'User';
}

?>