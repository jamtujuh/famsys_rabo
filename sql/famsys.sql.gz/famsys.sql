-- MySQL dump 10.11
--
-- Host: localhost    Database: famsys
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_globals`
--

DROP TABLE IF EXISTS `account_globals`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `account_globals` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(20) collate latin1_general_ci default NULL,
  `name` varchar(200) collate latin1_general_ci default NULL,
  `level` int(11) default NULL,
  `parent_id` int(11) default NULL,
  `detail` tinyint(1) default '0',
  PRIMARY KEY  (`id`),
  KEY `FKIndex1` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `account_globals`
--

LOCK TABLES `account_globals` WRITE;
/*!40000 ALTER TABLE `account_globals` DISABLE KEYS */;
INSERT INTO `account_globals` VALUES (1,'01','Aktiva Tetap',1,NULL,0),(2,'0101','Biaya Perolehan',2,1,0),(3,'010101','Pemilikan langsung',3,2,0),(4,'01010101','Gedung',4,3,1),(5,'01010102','Tanah',4,3,1),(6,'01010103','Instalasi dan Renovasi Bangunan',4,3,1),(7,'01010104','Kendaraan Bermotor',4,3,1),(8,'01010105','Perabotan Kantor',4,3,1),(9,'01010106','Peralatan Kantor',4,3,1),(10,'01010107','Piranti Lunak Komputer',4,3,1),(11,'01010108','Piranti Keras Komputer',4,3,1),(12,'010102','Aktiva Tetap Dalam Penyelesaian',3,2,1),(13,'0102','Akumulasi Penyusutan',2,1,0),(14,'010201','Pemilikan langsung',3,13,0),(15,'01020101','Gedung',4,14,1),(16,'01020102','Tanah',4,14,1),(17,'01020103','Instalasi dan Renovasi Bangunan',4,14,1),(18,'01020104','Kendaraan Bermotor',4,14,1),(19,'01020105','Perabotan Kantor',4,14,1),(20,'01020106','Peralatan Kantor',4,14,1),(21,'01020107','Piranti Lunak Komputer',4,14,1),(22,'01020108','Piranti Keras Komputer',4,14,1);
/*!40000 ALTER TABLE `account_globals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_types`
--

DROP TABLE IF EXISTS `account_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `account_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `descr` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `account_types`
--

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
INSERT INTO `account_types` VALUES (1,'Akumulasi Penyusutan',''),(2,'Harga Perolehan',''),(3,'Laba Penjualan FA',''),(4,'Rugi Penjualan FA',''),(5,'RAB Proses Umum',''),(6,'Biaya Penyusutan',''),(7,'Cabang Asal',''),(8,'Cabang Tujuan',''),(9,'Biaya Non Operasional',''),(10,'Hutang Supplier',''),(11,'Rugi Penghapusan FA',''),(12,'Laba Penghapusan FA','');
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `accounts` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(200) collate latin1_general_ci default NULL,
  `gl` varchar(50) collate latin1_general_ci default NULL,
  `linked_gol` tinyint(1) default '0',
  `debit` tinyint(1) default '0',
  `credit` tinyint(1) default '0',
  `account_global_id` int(11) default '0',
  `account_type_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FKIndex1` (`account_global_id`),
  KEY `account_type_id` (`account_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Building','1080-03',1,1,0,4,2),(2,'Akumulasi Penyusutan Building','1081-01',0,0,1,14,1),(3,'Biaya Penyusutan Building','5320-14',0,1,0,1,6),(4,'Hardware dan Instalation ','1080-06 ',1,1,0,6,2),(5,'Akumulasi Penyusutan Hardware dan Instalasi','1081-04',0,0,1,17,1),(6,'Biaya Penyusutan Hardware dan Instalation ','5323-14',0,1,0,1,6),(7,'Vehicle','1080-05',1,1,0,7,2),(8,'Akumulasi Penyusutan Vehicle','1081-03',0,0,1,7,1),(9,'Biaya Penyusutan Vehicle','5322-14',0,1,0,1,6),(92,'Biaya Penyusutan Software','5328-14',0,0,1,10,6),(20,'Software','1080-10',0,0,1,10,2),(21,'Akumulasi Penyusutan Software','1081-09',0,1,0,10,1),(24,'PPN','59000000',0,1,1,0,0),(38,'PPH 23','45108',0,1,1,0,0),(39,'RAB Proses Umum','0010999993',0,0,0,1,5),(55,'KERUGIAN PENGHAPUSAN FA','FA00001',0,1,1,NULL,11),(56,'KEUNTUNGAN PENJUALAN FA','FA00002',0,1,1,NULL,3),(57,'KERUGIAN PENJUALAN FA','FA00003',0,1,1,NULL,4),(58,'KAS','FA00004',0,0,0,0,0),(59,'Hutang Pada Supplier','1234567',0,1,1,1,10),(98,'Biaya Penyusutan Equipment','5330-14 ',0,0,1,1,6),(97,'Akumulasi Penyusutan Equipment','1081-11',0,1,0,1,1),(96,'Equipment','1080-12 ',0,1,0,1,2),(95,'Biaya Penyusutan Leasehold','5329-14 ',0,0,1,1,6),(94,'Akumulasi Penyusutan Leasehold','1081-10 ',0,1,0,1,1),(99,'Land ','1080-01',0,1,0,5,2),(100,'Akumulasi Penyusutan Land','1081-08 ',0,1,0,16,1),(101,'Biaya Penyusutan Land','5327-14 ',0,0,1,16,6),(102,'ACCOUNT CABANG ASAL','00000',0,1,1,NULL,7),(103,'ACCOUNT CABANG TUJUAN ','0000',0,0,0,NULL,8),(93,'Leasehold','1080-11',0,1,0,1,2),(104,'Biaya Non Operasional Lainnya','0000000',0,1,1,NULL,9),(105,'Amortisasi','2222',0,0,0,NULL,2),(106,'Akumulasi Penyusutan Amortisasi','3333',0,0,0,NULL,1),(107,'Biaya Penyusutan Amortisasi','4444',0,0,0,NULL,1);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_categories`
--

DROP TABLE IF EXISTS `asset_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `asset_categories` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `code` varchar(20) NOT NULL,
  `name` varchar(40) default NULL,
  `descr` tinytext NOT NULL,
  `id_parent` varchar(20) default NULL,
  `depr_year_com` int(10) unsigned default '0',
  `depr_rate_com` decimal(10,2) NOT NULL,
  `depr_year_fis` int(11) NOT NULL,
  `depr_rate_fis` decimal(10,2) NOT NULL,
  `account_id` int(11) NOT NULL,
  `account_depr_accumulated_id` int(11) NOT NULL,
  `account_depr_cost_id` int(11) NOT NULL,
  `is_asset` tinyint(1) NOT NULL default '1',
  `is_amort` tinyint(1) NOT NULL default '1',
  `asset_category_type_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `golongan_FKIndex1` (`id_parent`),
  KEY `account_id` (`account_id`),
  KEY `account_depr_accumulated_id` (`account_depr_accumulated_id`,`account_depr_cost_id`),
  KEY `is_asset` (`is_asset`),
  KEY `is_amort` (`is_amort`),
  KEY `asset_category_type_id` (`asset_category_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `asset_categories`
--

LOCK TABLES `asset_categories` WRITE;
/*!40000 ALTER TABLE `asset_categories` DISABLE KEYS */;
INSERT INTO `asset_categories` VALUES (1,'TNH','Tanah','','0',5,'20.00',4,'25.00',0,0,0,1,1,1),(2,'ADP','Bangunan Dalam Penyelesaian','','0',5,'0.00',4,'0.00',4,5,0,1,1,1),(3,'GDN','Gedung','','0',5,'0.00',4,'0.00',1,2,3,1,1,1),(4,'INS','Instalasi','','0',5,'0.00',0,'0.00',4,0,0,1,1,1),(5,'KND','Kendaraan','','0',5,'0.00',0,'0.00',13,14,15,1,1,1),(6,'HRD','Hardware Komputer','','0',5,'0.00',0,'0.00',16,17,18,1,1,1),(7,'PRP','Peripheral Komputer','','0',5,'0.00',0,'0.00',0,0,0,1,1,1),(8,'IN1','Inventaris Golongan I','','0',5,'0.00',0,'0.00',0,0,0,1,1,1),(9,'IN2','Inventaris Golongan II','','0',5,'0.00',0,'0.00',0,0,0,1,1,1),(10,'SWK','Software Komputer','','0',5,'0.00',0,'0.00',0,0,0,1,1,1),(11,'LSH','Leasehold','','0',5,'0.00',0,'0.00',0,0,0,1,1,1),(12,'MD','Perangkat Multimedia','','0',2,'10.00',4,'20.00',0,0,0,0,1,2),(13,'MD2','Perangkat Multimedia 2','','0',4,'10.00',2,'25.00',2,0,0,0,1,2),(14,'ATK','Alat Tulis Kantor','','0',4,'25.00',3,'20.00',1,0,0,0,1,2),(15,'ATK2','Alat Tulis Kantor 2','','0',3,'20.00',5,'25.00',2,0,0,0,1,2),(16,'REN','Renovasi','','',5,'20.00',4,'20.00',0,0,0,1,0,3);
/*!40000 ALTER TABLE `asset_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_category_types`
--

DROP TABLE IF EXISTS `asset_category_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `asset_category_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `asset_category_types`
--

LOCK TABLES `asset_category_types` WRITE;
/*!40000 ALTER TABLE `asset_category_types` DISABLE KEYS */;
INSERT INTO `asset_category_types` VALUES (1,'FA'),(2,'Stock'),(3,'Bdd');
/*!40000 ALTER TABLE `asset_category_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_details`
--

DROP TABLE IF EXISTS `asset_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `asset_details` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `code` varchar(40) NOT NULL,
  `condition_id` int(11) NOT NULL default '1',
  `asset_id` int(11) default NULL,
  `asset_category_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `location_id` int(11) default NULL,
  `department_id` int(11) default NULL,
  `setatus` char(1) default NULL,
  `kd_gab` varchar(30) default NULL,
  `name` varchar(40) default NULL,
  `color` varchar(20) default NULL,
  `brand` varchar(20) default NULL,
  `type` varchar(20) default NULL,
  `ada` char(1) default NULL,
  `date_of_purchase` date NOT NULL default '0000-00-00',
  `date_out` date default '0000-00-00',
  `kelfa` char(1) default NULL,
  `umurek` int(10) unsigned default NULL,
  `maksi` int(11) default NULL,
  `price` decimal(20,2) default '0.00',
  `price_cur` decimal(20,2) default '0.00',
  `residu` decimal(20,2) default '0.00',
  `akdasar` decimal(20,2) default '0.00',
  `depbln` decimal(20,2) default '0.00',
  `thnlalu` int(11) default '0',
  `blnlalu` int(10) unsigned default '0',
  `blnini` int(10) unsigned default '0',
  `jan` decimal(10,2) default '0.00',
  `feb` decimal(10,2) default '0.00',
  `mar` decimal(10,2) default '0.00',
  `apr` decimal(10,2) default '0.00',
  `may` decimal(10,2) default '0.00',
  `jun` decimal(10,2) default '0.00',
  `jul` decimal(10,2) default '0.00',
  `aug` decimal(10,2) default '0.00',
  `sep` decimal(10,2) default '0.00',
  `oct` decimal(10,2) default '0.00',
  `nov` decimal(10,2) default '0.00',
  `dec` decimal(20,2) default '0.00',
  `hrgjual` decimal(10,2) default '0.00',
  `jthnlalu` decimal(10,2) unsigned default '0.00',
  `jblnlalu` decimal(10,2) unsigned default '0.00',
  `jblnini` decimal(10,2) unsigned default '0.00',
  `hpthnlalu` decimal(10,2) unsigned default '0.00',
  `hpblnlalumasuk` decimal(10,2) unsigned default '0.00',
  `hpblninimasuk` decimal(20,2) unsigned default '0.00',
  `hpblnlalukeluar` decimal(20,2) unsigned default '0.00',
  `hpblninikeluar` decimal(20,2) unsigned default '0.00',
  `hpthnini` decimal(20,2) unsigned default '0.00',
  `depthnlalu` decimal(20,2) unsigned default '0.00',
  `depblnlalumasuk` decimal(20,2) unsigned default '0.00',
  `depblninimasuk` decimal(20,2) unsigned default '0.00',
  `depblnlalukeluar` decimal(20,2) unsigned default '0.00',
  `depblninikeluar` decimal(20,2) unsigned default '0.00',
  `depthnini` decimal(20,2) unsigned default '0.00',
  `book_value` decimal(20,2) unsigned default '0.00',
  `sedang_diluar` char(1) default 'N',
  `service_tanggal` date default NULL,
  `service_selesai_tanggal` date default NULL,
  `date_start` date default NULL,
  `date_end` date default NULL,
  `no_urut_prefix` varchar(30) default NULL,
  `no_urut` int(5) unsigned zerofill default NULL,
  `serial_no` varchar(20) default NULL,
  `voucher_no` varchar(15) default NULL,
  `posting` tinyint(1) NOT NULL default '0',
  `kd_luar_tanggal` date NOT NULL default '0000-00-00',
  `service_total` decimal(20,0) default '0',
  `service_ket` varchar(50) default NULL,
  `year` int(11) NOT NULL,
  `notes` text NOT NULL,
  `process` tinyint(1) NOT NULL default '0',
  `source` varchar(20) NOT NULL default 'purchase',
  `invoice_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `barang_detil_FKIndex1` (`asset_id`),
  KEY `barang_detil_FKIndex2` (`location_id`),
  KEY `barang_detil_FKIndex3` (`department_id`),
  KEY `barang_detil_FKIndex4` (`condition_id`),
  KEY `id_purchase` (`purchase_id`),
  KEY `posting` (`posting`),
  KEY `id_asset_category` (`asset_category_id`),
  KEY `process` (`process`),
  KEY `source` (`source`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=236 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `asset_details`
--

LOCK TABLES `asset_details` WRITE;
/*!40000 ALTER TABLE `asset_details` DISABLE KEYS */;
INSERT INTO `asset_details` VALUES (1,'8-2011-1-001-transfered-transfered-trans',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(2,'8-2011-1-002-transfered-transfered-trans',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(3,'8-2011-1-003-transfered',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(4,'8-2011-1-004-transfered',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(5,'8-2011-1-005-transfered',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(6,'8-2011-1-006',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(7,'8-2011-1-007',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(8,'8-2011-1-008',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(9,'8-2011-1-009',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(10,'8-2011-1-010',1,1,8,38,NULL,4,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(11,'6-2011-1-001',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(12,'6-2011-1-002',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(13,'6-2011-1-003',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(14,'6-2011-1-004',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(15,'6-2011-1-005',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(16,'6-2011-1-006',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(17,'6-2011-1-007',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(18,'6-2011-1-008',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(19,'6-2011-1-009',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(20,'6-2011-1-010',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(21,'6-2011-1-011',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(22,'6-2011-1-012',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(23,'6-2011-1-013',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(24,'6-2011-1-014',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(25,'6-2011-1-015',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(26,'6-2011-1-016',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(27,'6-2011-1-017',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(28,'6-2011-1-018',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(29,'6-2011-1-019',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(30,'6-2011-1-020',1,2,6,38,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',3),(31,'6-2011-2-001',1,3,6,39,1,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(32,'6-2011-2-002',1,3,6,39,1,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(33,'6-2011-2-003',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(34,'6-2011-2-004',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(35,'6-2011-2-005',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(36,'6-2011-2-006',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(37,'6-2011-2-007',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(38,'6-2011-2-008',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(39,'6-2011-2-009',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(40,'6-2011-2-010',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(41,'6-2011-2-011',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(42,'6-2011-2-012',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(43,'6-2011-2-013',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(44,'6-2011-2-014',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(45,'6-2011-2-015',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(46,'6-2011-2-016',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(47,'6-2011-2-017',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(48,'6-2011-2-018',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(49,'6-2011-2-019',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(50,'6-2011-2-020',1,3,6,39,NULL,8,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','0.00','0.00','8250.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(51,'6-2011-3-001',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(52,'6-2011-3-002',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(53,'6-2011-3-003',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(54,'6-2011-3-004',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(55,'6-2011-3-005',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(56,'6-2011-3-006-transfered',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(57,'6-2011-3-007-transfered',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(58,'6-2011-3-008',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(59,'6-2011-3-009',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(60,'6-2011-3-010',1,4,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(61,'6-2011-4-001',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(62,'6-2011-4-002',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(63,'6-2011-4-003',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(64,'6-2011-4-004',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(65,'6-2011-4-005',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(66,'6-2011-4-006',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(67,'6-2011-4-007',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(68,'6-2011-4-008',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(69,'6-2011-4-009',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(70,'6-2011-4-010',1,5,6,39,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','0.00','0.00','73333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',4),(71,'12-2011-1-001',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(72,'12-2011-1-002',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(73,'12-2011-1-003',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(74,'12-2011-1-004',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(75,'12-2011-1-005',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(76,'12-2011-1-006',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(77,'12-2011-1-007',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(78,'12-2011-1-008',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(79,'12-2011-1-009',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(80,'12-2011-1-010',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(81,'12-2011-1-011',1,6,12,40,NULL,4,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','0.00','0.00','2291.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',5),(82,'8-2011-1-001',1,1,8,38,NULL,9,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(83,'8-2011-1-002',1,1,8,38,NULL,9,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(84,'8-2011-1-001-transfered',1,1,8,38,NULL,9,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25','2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(85,'8-2011-1-002-transfered',1,1,8,38,NULL,9,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25','2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(86,'8-2011-1-001-transfered-transfered',1,1,8,38,NULL,9,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25','2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(87,'8-2011-1-002-transfered-transfered',1,1,8,38,NULL,9,NULL,NULL,'K-019-Meja Kerja','','','','T','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25','2011-04-25',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(88,'6-2011-3-006',1,4,6,39,NULL,6,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',4),(89,'6-2011-3-007',1,4,6,39,NULL,6,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',4),(90,'8-2011-1-003',1,1,8,38,NULL,1,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(91,'8-2011-1-004',1,1,8,38,NULL,1,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(92,'8-2011-1-005',1,1,8,38,NULL,1,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','0.00','0.00','9166.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'mutasi',3),(132,'SWK-2011-MAT-1-010',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(131,'SWK-2011-MAT-1-009',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(130,'SWK-2011-MAT-1-008',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(129,'SWK-2011-MAT-1-007',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(128,'SWK-2011-MAT-1-006',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(127,'SWK-2011-MAT-1-005',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(126,'SWK-2011-MAT-1-004',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(125,'SWK-2011-MAT-1-003',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(124,'SWK-2011-MAT-1-002',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(123,'SWK-2011-MAT-1-001',1,10,10,42,NULL,4,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','0.00','0.00','8333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(159,'HRD-2011--1-010',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(158,'HRD-2011--1-009',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(157,'HRD-2011--1-008',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(156,'HRD-2011--1-007',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(155,'HRD-2011--1-006',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(154,'HRD-2011--1-005',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(153,'HRD-2011--1-004',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(152,'HRD-2011--1-003',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(151,'HRD-2011--1-002',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(147,'INS-2011-SEL-1-001',1,16,4,42,NULL,1,NULL,NULL,'install',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'6000000.00','6000000.00','0.00','0.00','100000.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',0),(150,'HRD-2011--1-001',1,19,6,43,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(232,'HRD-2011-SEC-3-002',1,29,6,46,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(233,'HRD-2011-SEC-3-003',1,29,6,46,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(234,'HRD-2011-SEC-3-004',1,29,6,46,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(235,'HRD-2011-SEC-3-005',1,29,6,46,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(211,'HRD-2011-MAT-2-001',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(212,'HRD-2011-MAT-2-002',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(213,'HRD-2011-MAT-2-003',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(214,'HRD-2011-MAT-2-004',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(215,'HRD-2011-MAT-2-005',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(216,'HRD-2011-MAT-2-006',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(217,'HRD-2011-MAT-2-007',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(218,'HRD-2011-MAT-2-008',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(219,'HRD-2011-MAT-2-009',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(220,'HRD-2011-MAT-2-010',1,27,6,46,NULL,4,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(221,'HRD-2011-MAT-3-001',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(222,'HRD-2011-MAT-3-002',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(223,'HRD-2011-MAT-3-003',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(224,'HRD-2011-MAT-3-004',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(225,'HRD-2011-MAT-3-005',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(226,'HRD-2011-MAT-3-006',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(227,'HRD-2011-MAT-3-007',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(228,'HRD-2011-MAT-3-008',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(229,'HRD-2011-MAT-3-009',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(230,'HRD-2011-MAT-3-010',1,28,6,46,NULL,4,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','0.00','0.00','82500.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6),(231,'HRD-2011-SEC-3-001',1,29,6,46,NULL,8,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','0.00','0.00','102666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,'purchase',6);
/*!40000 ALTER TABLE `asset_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_outs`
--

DROP TABLE IF EXISTS `asset_outs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `asset_outs` (
  `id` varchar(8) NOT NULL default '',
  `tanggal` date default NULL,
  `alasan` varchar(15) default NULL,
  `description` varchar(100) default NULL,
  `id_warranty` varchar(4) default '0',
  `id_asset_detail` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `id_asset_detailx` (`id_asset_detail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `asset_outs`
--

LOCK TABLES `asset_outs` WRITE;
/*!40000 ALTER TABLE `asset_outs` DISABLE KEYS */;
INSERT INTO `asset_outs` VALUES ('00001','2005-04-28','SERVICE','','0','E-CE-CPU-27/01/2005-1-001/001'),('00002','2005-04-28','SERVICE','Rusak','Q000','E-CE-CPU-27/01/2005-1-001/001'),('00003','2005-07-26','DIPINJAMKA','baik','0','E-AV-CD-26/07/2005-1-001'),('00004','2005-07-26','SERVICE','baik','D004','E-AV-CD-26/07/2005-1-001'),('00005','2005-07-26','SERVICE','Rusak','D004','E-AV-DVD-27/01/2005-1-004'),('S-00001','2005-07-29','SERVICE','rusak','D012','E-AV-DVD-27/01/2005-1-003'),('S-00002','2005-07-29','SERVICE','yrtyt','D012','E-AV-DVD-27/01/2005-1-004'),('S-00003','2005-07-29','SERVICE','serter','Q000','E-AV-DVD-27/07/2005-1-001'),('S-00004','2005-08-12','SERVICE','rusak','G001','E-CE-MONITOR-08/08/2005-1-001'),('S-00005','2005-08-12','SERVICE','rusak','0','E-CO-HP-12/08/2005-1-001'),('S-00006','2005-08-15','SERVICE','rusak','BST','E-CO-HP-12/08/2005-1-001'),('S-00007','2005-08-15','SERVICE','perubahan ke dua','Q000','E-CE-PRINTER-15/08/2005-1-001'),('S-00008','2005-08-15','DIPINJAMKA','pinjam sebentar','G001','E-CE-SCANNER-28/06/2005-1-001'),('S-00009','2005-08-23','SERVICE','Rusak','D004','E-CE-CPU-07/07/2005-1-001'),('S-00010','2008-05-21','DIPINJAMKAN','pinjam ke acabang','D004','E-BE-GENSET-21/05/2008-1-002');
/*!40000 ALTER TABLE `asset_outs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `assets` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `code` varchar(40) NOT NULL,
  `condition_id` int(11) NOT NULL,
  `asset_category_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `location_id` int(11) default NULL,
  `currency_id` int(11) default NULL,
  `department_id` int(11) default NULL,
  `warranty_id` int(11) NOT NULL,
  `setatus` char(1) default NULL,
  `kd_gab` varchar(30) default NULL,
  `name` varchar(40) default NULL,
  `color` varchar(20) default NULL,
  `brand` varchar(20) default NULL,
  `type` varchar(20) default NULL,
  `ada` char(1) default NULL,
  `date_of_purchase` date NOT NULL default '0000-00-00',
  `date_out` date default '0000-00-00',
  `kelfa` char(1) default NULL,
  `umurek` int(10) unsigned default NULL,
  `maksi` int(11) default NULL,
  `price` decimal(20,2) default '0.00',
  `price_cur` decimal(20,2) default '0.00',
  `amount` decimal(20,2) default '0.00',
  `amount_cur` decimal(20,2) default '0.00',
  `qty` int(11) default '0',
  `residu` decimal(20,2) default '0.00',
  `akdasar` decimal(20,2) default '0.00',
  `depbln` decimal(20,2) default '0.00',
  `thnlalu` int(11) default '0',
  `blnlalu` int(10) unsigned default '0',
  `blnini` int(10) unsigned default '0',
  `jan` decimal(10,2) default '0.00',
  `feb` decimal(10,2) default '0.00',
  `mar` decimal(10,2) default '0.00',
  `apr` decimal(10,2) default '0.00',
  `may` decimal(10,2) default '0.00',
  `jun` decimal(10,2) default '0.00',
  `jul` decimal(10,2) default '0.00',
  `aug` decimal(10,2) default '0.00',
  `sep` decimal(10,2) default '0.00',
  `oct` decimal(10,2) default '0.00',
  `nov` decimal(10,2) default '0.00',
  `dec` decimal(20,2) default '0.00',
  `hrgjual` decimal(10,2) default '0.00',
  `jthnlalu` decimal(10,2) unsigned default '0.00',
  `jblnlalu` decimal(10,2) unsigned default '0.00',
  `jblnini` decimal(10,2) unsigned default '0.00',
  `hpthnlalu` decimal(10,2) unsigned default '0.00',
  `hpblnlalumasuk` decimal(10,2) unsigned default '0.00',
  `hpblninimasuk` decimal(20,2) unsigned default '0.00',
  `hpblnlalukeluar` decimal(20,2) unsigned default '0.00',
  `hpblninikeluar` decimal(20,2) unsigned default '0.00',
  `hpthnini` decimal(20,2) unsigned default '0.00',
  `depthnlalu` decimal(20,2) unsigned default '0.00',
  `depblnlalumasuk` decimal(20,2) unsigned default '0.00',
  `depblninimasuk` decimal(20,2) unsigned default '0.00',
  `depblnlalukeluar` decimal(20,2) unsigned default '0.00',
  `depblninikeluar` decimal(20,2) unsigned default '0.00',
  `depthnini` decimal(20,2) unsigned default '0.00',
  `book_value` decimal(20,2) unsigned default '0.00',
  `sedang_diluar` char(1) default 'N',
  `service_tanggal` date default NULL,
  `service_selesai_tanggal` date default NULL,
  `date_start` date default NULL,
  `date_end` date default NULL,
  `no_urut_prefix` varchar(30) default NULL,
  `no_urut` int(5) unsigned zerofill default NULL,
  `serial_no` varchar(20) default NULL,
  `voucher_no` varchar(15) default NULL,
  `po_no` varchar(15) default NULL,
  `invoice_no` varchar(15) default NULL,
  `posting` tinyint(1) NOT NULL default '0',
  `kd_luar_tanggal` date NOT NULL default '0000-00-00',
  `service_total` decimal(20,0) default '0',
  `service_ket` varchar(50) default NULL,
  `year` int(11) NOT NULL,
  `notes` tinytext NOT NULL,
  `process` tinyint(1) NOT NULL default '0',
  `invoice_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_purchase` (`purchase_id`),
  KEY `id_asset_category` (`asset_category_id`),
  KEY `id_department` (`department_id`),
  KEY `id_warranty` (`warranty_id`),
  KEY `id_currency` (`currency_id`),
  KEY `invoice_no` (`invoice_no`),
  KEY `po_no` (`po_no`),
  KEY `posting` (`posting`),
  KEY `process` (`process`),
  KEY `invoice_id` (`invoice_id`),
  KEY `price` (`price`,`price_cur`,`amount`,`amount_cur`,`qty`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (1,'8-2011-1',0,8,38,NULL,0,1,0,NULL,NULL,'K-019-Meja Kerja','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','5500000.00','5500000.00',10,'0.00','0.00','91666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,3),(2,'6-2011-1',0,6,38,NULL,0,8,0,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4950000.00','4950000.00','99000000.00','99000000.00',20,'0.00','0.00','1650000.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,3),(3,'6-2011-2',0,6,39,NULL,0,8,0,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'495000.00','495000.00','9900000.00','9900000.00',20,'0.00','0.00','165000.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,4),(4,'6-2011-3',0,6,39,NULL,0,6,0,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'550000.00','550000.00','5500000.00','5500000.00',10,'0.00','0.00','91666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,4),(5,'6-2011-4',0,6,39,NULL,0,4,0,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-25','0000-00-00',NULL,5,60,'4400000.00','4400000.00','44000000.00','44000000.00',10,'0.00','0.00','733333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,4),(6,'12-2011-1',0,12,40,NULL,1,4,0,NULL,NULL,'MD-023-Speaker','','','','Y','2011-04-25','0000-00-00',NULL,2,24,'55000.00','55000.00','605000.00','605000.00',11,'0.00','0.00','25208.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,5),(10,'SWK-2011-MAT-1',0,10,42,NULL,1,4,0,NULL,NULL,'windows',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'500000.00','500000.00','5000000.00','5000000.00',10,'0.00','0.00','83333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,0),(16,'INS-2011-SEL-1',0,4,42,NULL,1,1,0,NULL,NULL,'install',NULL,NULL,NULL,'Y','2011-04-29','0000-00-00',NULL,5,60,'6000000.00','6000000.00','6000000.00','6000000.00',1,'0.00','0.00','100000.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,'2011-04-29','2016-03-29',NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,0),(19,'HRD-2011--1',0,6,43,NULL,0,4,0,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','61600000.00','61600000.00',10,'0.00','0.00','1026666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,6),(29,'HRD-2011-SEC-3',0,6,46,NULL,0,8,0,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','30800000.00','30800000.00',5,'0.00','0.00','513333.33',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,6),(27,'HRD-2011-MAT-2',0,6,46,NULL,0,4,0,NULL,NULL,'K099-Komputer Lengkap 2','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'6160000.00','6160000.00','61600000.00','61600000.00',10,'0.00','0.00','1026666.67',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,6),(28,'HRD-2011-MAT-3',0,6,46,NULL,0,4,0,NULL,NULL,'K0199-Printer lengkap','','','','Y','2011-04-29','0000-00-00',NULL,5,60,'4950000.00','4950000.00','49500000.00','49500000.00',10,'0.00','0.00','825000.00',0,0,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'0000-00-00','0',NULL,2011,'',0,6);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ayda_ages`
--

DROP TABLE IF EXISTS `ayda_ages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ayda_ages` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `low` int(11) default NULL,
  `high` int(11) default NULL,
  `ppap_pct` int(11) default NULL,
  `id_ayda_status` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKIndex1` (`id_ayda_status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ayda_ages`
--

LOCK TABLES `ayda_ages` WRITE;
/*!40000 ALTER TABLE `ayda_ages` DISABLE KEYS */;
INSERT INTO `ayda_ages` VALUES (1,0,1,15,1),(2,1,3,15,1),(3,3,5,50,2),(4,5,2000,100,3);
/*!40000 ALTER TABLE `ayda_ages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ayda_docs`
--

DROP TABLE IF EXISTS `ayda_docs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ayda_docs` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `nama` varchar(50) collate latin1_general_ci default NULL,
  `heading` int(11) default '0',
  `kode` varchar(10) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ayda_docs`
--

LOCK TABLES `ayda_docs` WRITE;
/*!40000 ALTER TABLE `ayda_docs` DISABLE KEYS */;
INSERT INTO `ayda_docs` VALUES (1,'SERTIFIKAT',1,'01'),(2,'SHM',0,'0101'),(3,'SHGB',0,'0102'),(4,'SHRSS',0,'0103'),(5,'BPKB',0,'02');
/*!40000 ALTER TABLE `ayda_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ayda_insurances`
--

DROP TABLE IF EXISTS `ayda_insurances`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ayda_insurances` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `nama` varchar(50) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ayda_insurances`
--

LOCK TABLES `ayda_insurances` WRITE;
/*!40000 ALTER TABLE `ayda_insurances` DISABLE KEYS */;
INSERT INTO `ayda_insurances` VALUES (1,'Asuransi Jiwa'),(2,'Asuransi Kebakaran');
/*!40000 ALTER TABLE `ayda_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ayda_statuses`
--

DROP TABLE IF EXISTS `ayda_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ayda_statuses` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `nama` varchar(50) collate latin1_general_ci default NULL,
  `low` int(11) default NULL,
  `high` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ayda_statuses`
--

LOCK TABLES `ayda_statuses` WRITE;
/*!40000 ALTER TABLE `ayda_statuses` DISABLE KEYS */;
INSERT INTO `ayda_statuses` VALUES (1,'Lancar',0,15),(2,'Kurang lancar',15,50),(3,'Macet',50,100);
/*!40000 ALTER TABLE `ayda_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ayda_types`
--

DROP TABLE IF EXISTS `ayda_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ayda_types` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `nama` varchar(50) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ayda_types`
--

LOCK TABLES `ayda_types` WRITE;
/*!40000 ALTER TABLE `ayda_types` DISABLE KEYS */;
INSERT INTO `ayda_types` VALUES (1,'Tanah'),(3,'Apartemen'),(2,'Rumah'),(4,'Villa'),(5,'Pabrik'),(6,'Motorcycle'),(7,'Mesin'),(8,'Ruko'),(9,'Gedung'),(10,'Workshop '),(11,'Infrastruktur'),(12,'Kantor'),(13,'Kios'),(14,'Gudang');
/*!40000 ALTER TABLE `ayda_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aydas`
--

DROP TABLE IF EXISTS `aydas`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `aydas` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `debitor_nama` varchar(50) collate latin1_general_ci default NULL,
  `debitor_alamat` varchar(200) collate latin1_general_ci default NULL,
  `lokasi` varchar(200) collate latin1_general_ci default NULL,
  `sertifikat_nomor` varchar(50) collate latin1_general_ci default NULL,
  `sertifikat_tanggal` date default NULL,
  `sertifikat_jtempo` date default NULL,
  `asuransi_nomor` varchar(50) collate latin1_general_ci default NULL,
  `asuransi_jtempo` date default NULL,
  `nilai_buku` decimal(20,0) default NULL,
  `tanggal` date default NULL,
  `umur` int(11) default NULL,
  `ppap_pct` decimal(11,0) default NULL,
  `ppap_jumlah` decimal(20,0) default NULL,
  `appraisal_tanggal` date default NULL,
  `appraisal_jtempo` date default NULL,
  `appraisal_nilai_pasar` decimal(20,0) default NULL,
  `appraisal_nilai_likuidasi` decimal(20,0) default NULL,
  `pbb_stts` varchar(50) collate latin1_general_ci default NULL,
  `pbb_tahun` int(11) default NULL,
  `listrik_status` int(11) default '0',
  `listrik_daya` int(11) default NULL,
  `telephone_status` int(11) default '0',
  `telephone_jumlah_line` int(11) default NULL,
  `pam_status` int(11) default '0',
  `pemegang_kunci` varchar(50) collate latin1_general_ci default NULL,
  `sold` int(11) default '0',
  `ayda_status_id` int(11) default NULL,
  `department_id` int(11) NOT NULL default '0',
  `ayda_type_id` int(11) unsigned NOT NULL default '0',
  `ayda_insurance_id` int(11) unsigned NOT NULL default '0',
  `ayda_doc_id` int(11) unsigned NOT NULL default '0',
  `nilai_jual` decimal(20,0) default NULL,
  `ltlb` varchar(50) collate latin1_general_ci default NULL,
  `keterangan` text collate latin1_general_ci,
  PRIMARY KEY  (`id`),
  KEY `FKIndex2` (`ayda_type_id`),
  KEY `FKIndex3` (`ayda_insurance_id`),
  KEY `FKIndex4` (`ayda_doc_id`),
  KEY `FKIndex5` (`ayda_status_id`),
  KEY `FKIndex1` (`department_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `aydas`
--

LOCK TABLES `aydas` WRITE;
/*!40000 ALTER TABLE `aydas` DISABLE KEYS */;
/*!40000 ALTER TABLE `aydas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_account_types`
--

DROP TABLE IF EXISTS `bank_account_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bank_account_types` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `descr` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bank_account_types`
--

LOCK TABLES `bank_account_types` WRITE;
/*!40000 ALTER TABLE `bank_account_types` DISABLE KEYS */;
INSERT INTO `bank_account_types` VALUES (1,'Transfer',''),(2,'Giro',''),(3,'Cheque','');
/*!40000 ALTER TABLE `bank_account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_accounts`
--

DROP TABLE IF EXISTS `bank_accounts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL auto_increment,
  `supplier_id` int(11) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `bank_account_no` varchar(50) NOT NULL,
  `bank_account_name` varchar(200) NOT NULL,
  `bank_account_type_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `supplier_id` (`supplier_id`,`bank_account_type_id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bank_accounts`
--

LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
INSERT INTO `bank_accounts` VALUES (1,1,'BCA','12345667','Yanto',2,1),(2,1,'BRI','7645','Tono',3,2),(3,1,'BNI','456456','Asep',1,1),(11,2,'BCA','450030003','Shure Electronic',1,1),(15,19,'BNI','454353','Jajang',2,1),(17,19,'BCA','454353','Jajang',2,1);
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) collate latin1_general_ci NOT NULL default '0',
  `ip_address` varchar(16) collate latin1_general_ci NOT NULL default '0',
  `user_agent` varchar(50) collate latin1_general_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `session_data` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ci_sessions`
--

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `conditions` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(6) NOT NULL,
  `name` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `conditions`
--

LOCK TABLES `conditions` WRITE;
/*!40000 ALTER TABLE `conditions` DISABLE KEYS */;
INSERT INTO `conditions` VALUES (10,'JUAL','Dijual'),(3,'HILANG','Hilang'),(2,'RUSAK','Rusak'),(1,'BAGUS','Bagus'),(4,'IC','Intercoy');
/*!40000 ALTER TABLE `conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configs`
--

DROP TABLE IF EXISTS `configs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `configs` (
  `key` varchar(20) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `configs`
--

LOCK TABLES `configs` WRITE;
/*!40000 ALTER TABLE `configs` DISABLE KEYS */;
INSERT INTO `configs` VALUES ('depr_cut_date','15'),('po_notes','bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF '),('npb_notes','blan bpafhdsdfs dshfkjdskjfdskjfjds fhkdsjfjkdshf sfj dskfhs'),('po_shipping_address','Rabobank, \r\nJl Rasuna Said'),('po_billing_address','Rabobank,\r\nJl Rasuna Said'),('default_wht_rate','2.5'),('default_vat_rate','10'),('min_asset_value','5000000');
/*!40000 ALTER TABLE `configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL default '0',
  `name` varchar(4) default NULL,
  `rp_rate` decimal(10,2) default NULL,
  `last_update_tgl` datetime default NULL,
  `description` varchar(30) default NULL,
  `rp_BI_rate` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'Rp','1.00',NULL,'Rupiah',NULL),(2,'USD','10000.00','2005-10-24 14:18:00','Dolar',10500),(3,'AUD','4750.00','2005-10-24 14:13:57','Dolar',0);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_details`
--

DROP TABLE IF EXISTS `currency_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `currency_details` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `currency_id` int(10) unsigned NOT NULL default '0',
  `tanggal` datetime default NULL,
  `rp_rate` float default NULL,
  `rp_BI_rate` float default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `currency_details`
--

LOCK TABLES `currency_details` WRITE;
/*!40000 ALTER TABLE `currency_details` DISABLE KEYS */;
INSERT INTO `currency_details` VALUES (1,3,'2005-10-24 14:13:57',4750,0),(2,2,'2005-10-24 14:18:58',10000,10500),(3,3,'2011-01-13 22:40:00',455,654),(4,1,'2011-04-16 12:59:00',NULL,NULL);
/*!40000 ALTER TABLE `currency_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_order_details`
--

DROP TABLE IF EXISTS `delivery_order_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `delivery_order_details` (
  `id` int(11) NOT NULL auto_increment,
  `delivery_order_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `po_detail_id` int(11) NOT NULL,
  `asset_category_id` varchar(29) NOT NULL,
  `name` varchar(40) NOT NULL,
  `color` varchar(10) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL default '0',
  `qty_received` int(11) NOT NULL default '0',
  `price` decimal(20,2) NOT NULL default '0.00',
  `price_cur` decimal(20,2) NOT NULL default '0.00',
  `amount` decimal(20,2) NOT NULL,
  `amount_cur` decimal(20,2) NOT NULL,
  `discount` decimal(20,2) NOT NULL default '0.00',
  `discount_cur` decimal(20,2) NOT NULL default '0.00',
  `amount_after_disc` decimal(20,2) NOT NULL,
  `amount_after_disc_cur` decimal(20,2) NOT NULL,
  `vat` decimal(20,2) NOT NULL,
  `vat_cur` decimal(20,2) NOT NULL,
  `amount_nett` decimal(20,2) NOT NULL default '0.00',
  `amount_nett_cur` decimal(20,2) NOT NULL default '0.00',
  `currency_id` int(11) NOT NULL,
  `rp_rate` decimal(20,2) NOT NULL default '1.00',
  `npb_id` int(11) NOT NULL,
  `umurek` int(11) NOT NULL,
  `is_vat` tinyint(1) NOT NULL default '1',
  `is_wht` tinyint(1) NOT NULL default '0',
  `department_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_asset_category` (`asset_category_id`),
  KEY `id_invoice` (`po_id`),
  KEY `id_npb` (`npb_id`),
  KEY `is_ppn` (`is_vat`,`is_wht`),
  KEY `department_id` (`department_id`),
  KEY `do_id` (`delivery_order_id`),
  KEY `po_detail_id` (`po_detail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `delivery_order_details`
--

LOCK TABLES `delivery_order_details` WRITE;
/*!40000 ALTER TABLE `delivery_order_details` DISABLE KEYS */;
INSERT INTO `delivery_order_details` VALUES (1,1,16,79,'10','ms windows','','','',10,5,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',0,'1.00',0,0,1,0,0),(2,1,16,80,'7','komputer ibm','','','',10,2,'0.00','15000000.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00',0,'1.00',0,0,0,0,0),(3,1,16,82,'3','ruang rapat','','','',1,0,'0.00','4000000.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00',0,'1.00',0,0,0,0,0),(4,1,16,84,'6','laptop','','','',10,15,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00',0,'1.00',0,0,0,0,0),(5,2,16,79,'10','ms windows','','','',8,3,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',0,'1.00',0,0,1,0,0),(6,2,16,80,'7','komputer ibm','','','',10,0,'0.00','15000000.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00',0,'1.00',0,0,0,0,0),(7,2,16,82,'3','ruang rapat','','','',1,0,'0.00','4000000.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00',0,'1.00',0,0,0,0,0),(8,2,16,84,'6','laptop','','','',10,0,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00',0,'1.00',0,0,0,0,0),(9,3,16,79,'10','ms windows','','','',5,5,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',0,'1.00',0,0,1,0,0),(10,3,16,80,'7','komputer ibm','','','',10,10,'0.00','15000000.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00',0,'1.00',0,0,0,0,0),(11,3,16,82,'3','ruang rapat','','','',1,0,'0.00','4000000.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00',0,'1.00',0,0,0,0,0),(12,3,16,84,'6','laptop','','','',10,9,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00',0,'1.00',0,0,0,0,0),(13,4,16,79,'10','ms windows','','','',0,0,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',0,'1.00',0,0,1,0,0),(14,4,16,80,'7','komputer ibm','','','',-2,0,'0.00','15000000.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00',0,'1.00',0,0,0,0,0),(15,4,16,82,'3','ruang rapat','','','',1,1,'0.00','4000000.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00',0,'1.00',0,0,0,0,0),(16,4,16,84,'6','laptop','','','',0,0,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00',0,'1.00',0,0,0,0,0),(17,5,16,79,'10','ms windows','','','',0,0,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',0,'1.00',0,0,1,0,0),(18,5,16,80,'7','komputer ibm','','','',0,0,'0.00','15000000.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00',0,'1.00',0,0,0,0,0),(19,5,16,82,'3','ruang rapat','','','',0,0,'0.00','4000000.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00',0,'1.00',0,0,0,0,0),(20,5,16,84,'6','laptop','','','',0,0,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00',0,'1.00',0,0,0,0,0),(21,6,16,79,'10','ms windows','','','',0,0,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',0,'1.00',0,0,1,0,0),(22,6,16,80,'7','komputer ibm','','','',0,0,'0.00','15000000.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00','0.00','0.00','150000000.00','150000000.00',0,'1.00',0,0,0,0,0),(23,6,16,82,'3','ruang rapat','','','',0,0,'0.00','4000000.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00','0.00','0.00','4000000.00','4000000.00',0,'1.00',0,0,0,0,0),(24,6,16,84,'6','laptop','','','',0,0,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00',0,'1.00',0,0,0,0,0),(25,7,13,72,'8','Kursi','','','',10,2,'0.00','1000000.00','10000000.00','10000000.00','600000.00','600000.00','9400000.00','9400000.00','940000.00','940000.00','10340000.00','10340000.00',0,'0.00',34,5,1,0,4),(26,8,13,72,'8','Kursi','','','',8,8,'0.00','1000000.00','10000000.00','10000000.00','600000.00','600000.00','9400000.00','9400000.00','940000.00','940000.00','10340000.00','10340000.00',0,'0.00',34,5,1,0,4),(27,9,17,95,'8','test','','','',1,1,'0.00','5000000000.00','5000000000.00','5000000000.00','0.00','0.00','5000000000.00','5000000000.00','0.00','0.00','5000000000.00','5000000000.00',0,'1.00',0,0,0,0,0),(28,10,23,85,'8','K-010-Kursi','','','',10,10,'0.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','49500000.00','49500000.00',0,'0.00',43,5,1,0,4),(29,10,23,86,'9','LMR001-Lemari Besi','','','',1,1,'0.00','4900000.00','4900000.00','4900000.00','0.00','0.00','4900000.00','4900000.00','490000.00','490000.00','5390000.00','5390000.00',0,'0.00',43,5,1,0,4),(30,11,1,2,'8','K-019-Meja Kerja','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',0,'0.00',1,5,1,0,4),(31,11,1,3,'6','K099-Komputer Lengkap 2','','','',20,20,'0.00','4500000.00','90000000.00','90000000.00','0.00','0.00','90000000.00','90000000.00','9000000.00','9000000.00','99000000.00','99000000.00',0,'0.00',2,5,1,0,8),(32,12,2,4,'6','K0199-Printer lengkap','','','',20,10,'0.00','450000.00','9000000.00','9000000.00','0.00','0.00','9000000.00','9000000.00','900000.00','900000.00','9900000.00','9900000.00',0,'0.00',2,5,1,0,8),(33,12,2,5,'6','K0199-Printer lengkap','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',0,'0.00',4,5,1,0,4),(34,12,2,7,'6','K0199-Printer lengkap','','','',10,10,'0.00','4000000.00','40000000.00','40000000.00','0.00','0.00','40000000.00','40000000.00','4000000.00','4000000.00','44000000.00','44000000.00',0,'0.00',5,5,1,0,4),(35,13,2,4,'6','K0199-Printer lengkap','','','',10,10,'0.00','450000.00','9000000.00','9000000.00','0.00','0.00','9000000.00','9000000.00','900000.00','900000.00','9900000.00','9900000.00',0,'0.00',2,5,1,0,8),(36,13,2,5,'6','K0199-Printer lengkap','','','',0,0,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',0,'0.00',4,5,1,0,4),(37,13,2,7,'6','K0199-Printer lengkap','','','',0,0,'0.00','4000000.00','40000000.00','40000000.00','0.00','0.00','40000000.00','40000000.00','4000000.00','4000000.00','44000000.00','44000000.00',0,'0.00',5,5,1,0,4),(38,14,5,6,'12','MD-023-Speaker','','','',11,11,'0.00','50000.00','550000.00','550000.00','0.00','0.00','550000.00','550000.00','55000.00','55000.00','605000.00','605000.00',1,'0.00',4,2,1,0,4),(39,15,17,10,'6','K099-Komputer Lengkap 2','','','',10,2,'0.00','5600000.00','56000000.00','56000000.00','0.00','0.00','56000000.00','56000000.00','5600000.00','5600000.00','61600000.00','61600000.00',0,'0.00',12,5,1,0,4),(40,15,17,11,'6','K0199-Printer lengkap','','','',10,2,'0.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','49500000.00','49500000.00',0,'0.00',12,5,1,0,4),(41,15,17,12,'6','K099-Komputer Lengkap 2','','','',5,2,'0.00','5600000.00','28000000.00','28000000.00','0.00','0.00','28000000.00','28000000.00','2800000.00','2800000.00','30800000.00','30800000.00',0,'0.00',13,5,1,0,8),(42,16,17,10,'6','K099-Komputer Lengkap 2','','','',8,3,'0.00','5600000.00','56000000.00','56000000.00','0.00','0.00','56000000.00','56000000.00','5600000.00','5600000.00','61600000.00','61600000.00',0,'0.00',12,5,1,0,4),(43,16,17,11,'6','K0199-Printer lengkap','','','',8,3,'0.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','49500000.00','49500000.00',0,'0.00',12,5,1,0,4),(44,16,17,12,'6','K099-Komputer Lengkap 2','','','',3,3,'0.00','5600000.00','28000000.00','28000000.00','0.00','0.00','28000000.00','28000000.00','2800000.00','2800000.00','30800000.00','30800000.00',0,'0.00',13,5,1,0,8),(45,17,17,10,'6','K099-Komputer Lengkap 2','','','',5,2,'0.00','5600000.00','56000000.00','56000000.00','0.00','0.00','56000000.00','56000000.00','5600000.00','5600000.00','61600000.00','61600000.00',0,'0.00',12,5,1,0,4),(46,17,17,11,'6','K0199-Printer lengkap','','','',5,2,'0.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','49500000.00','49500000.00',0,'0.00',12,5,1,0,4),(47,17,17,12,'6','K099-Komputer Lengkap 2','','','',0,0,'0.00','5600000.00','28000000.00','28000000.00','0.00','0.00','28000000.00','28000000.00','2800000.00','2800000.00','30800000.00','30800000.00',0,'0.00',13,5,1,0,8),(48,18,17,10,'6','K099-Komputer Lengkap 2','','','',3,3,'0.00','5600000.00','56000000.00','56000000.00','0.00','0.00','56000000.00','56000000.00','5600000.00','5600000.00','61600000.00','61600000.00',0,'0.00',12,5,1,0,4),(49,18,17,11,'6','K0199-Printer lengkap','','','',3,3,'0.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','49500000.00','49500000.00',0,'0.00',12,5,1,0,4),(50,18,17,12,'6','K099-Komputer Lengkap 2','','','',0,0,'0.00','5600000.00','28000000.00','28000000.00','0.00','0.00','28000000.00','28000000.00','2800000.00','2800000.00','30800000.00','30800000.00',0,'0.00',13,5,1,0,8);
/*!40000 ALTER TABLE `delivery_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_order_statuses`
--

DROP TABLE IF EXISTS `delivery_order_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `delivery_order_statuses` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `sorter` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `delivery_order_statuses`
--

LOCK TABLES `delivery_order_statuses` WRITE;
/*!40000 ALTER TABLE `delivery_order_statuses` DISABLE KEYS */;
INSERT INTO `delivery_order_statuses` VALUES (1,'New',0),(2,'Done',0);
/*!40000 ALTER TABLE `delivery_order_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_orders`
--

DROP TABLE IF EXISTS `delivery_orders`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `delivery_orders` (
  `id` int(11) NOT NULL auto_increment,
  `po_id` int(11) NOT NULL,
  `no` varchar(10) NOT NULL,
  `do_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `department_id` int(11) default NULL,
  `delivery_order_status_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `convert_invoice` int(11) NOT NULL default '0',
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `approval_info` text NOT NULL,
  `wht_rate` decimal(10,2) NOT NULL default '0.00',
  `vat_rate` decimal(10,2) NOT NULL default '10.00',
  `vat_base` decimal(20,2) NOT NULL default '0.00',
  `vat_base_cur` decimal(20,2) NOT NULL,
  `wht_base` decimal(20,2) NOT NULL default '0.00',
  `wht_base_cur` decimal(20,2) NOT NULL,
  `sub_total` decimal(20,2) NOT NULL,
  `sub_total_cur` decimal(20,2) NOT NULL,
  `discount` decimal(20,2) NOT NULL default '0.00',
  `discount_cur` decimal(20,2) NOT NULL,
  `after_disc` decimal(20,2) NOT NULL,
  `after_disc_cur` decimal(20,2) NOT NULL,
  `wht_total` decimal(20,2) NOT NULL default '0.00',
  `wht_total_cur` decimal(20,2) NOT NULL,
  `vat_total` decimal(20,2) NOT NULL default '0.00',
  `vat_total_cur` decimal(20,2) NOT NULL,
  `total` decimal(20,2) NOT NULL default '0.00',
  `total_cur` decimal(20,2) NOT NULL,
  `billing_address` text NOT NULL,
  `shipping_address` text NOT NULL,
  `rp_rate` decimal(20,2) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `id_supplier` (`supplier_id`),
  KEY `created` (`created`),
  KEY `id_department` (`department_id`),
  KEY `po_status_id` (`delivery_order_status_id`),
  KEY `delivery_date` (`delivery_date`),
  KEY `po_date` (`do_date`),
  KEY `currency_id` (`currency_id`),
  KEY `po_id` (`po_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `delivery_orders`
--

LOCK TABLES `delivery_orders` WRITE;
/*!40000 ALTER TABLE `delivery_orders` DISABLE KEYS */;
INSERT INTO `delivery_orders` VALUES (7,13,'DOO-032','2011-04-20','0000-00-00',1,1,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(2,16,'DO-02','2011-04-20','0000-00-00',19,1,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(3,16,'DO-03','2011-04-20','0000-00-00',19,1,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(4,16,'DO-04','2011-04-20','0000-00-00',19,1,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(5,16,'DO-0029','2011-04-20','0000-00-00',19,1,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(6,16,'DO593','2011-04-20','0000-00-00',19,1,1,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(8,13,'D2','2011-04-20','0000-00-00',1,1,1,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(15,17,'d21','2011-04-29','0000-00-00',8,NULL,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(10,23,'222','2011-04-21','0000-00-00',1,NULL,1,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(11,1,'D1','2011-04-25','0000-00-00',2,NULL,1,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(12,2,'12','2011-04-25','0000-00-00',1,NULL,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(14,5,'112','2011-04-25','0000-00-00',1,NULL,1,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(16,17,'d22','2011-04-29','0000-00-00',8,NULL,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(17,17,'d23','2011-04-29','0000-00-00',8,NULL,2,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00'),(18,17,'d24','2011-04-29','0000-00-00',8,NULL,1,0,'',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','','','0.00');
/*!40000 ALTER TABLE `delivery_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `code` char(3) NOT NULL,
  `name` char(40) default NULL,
  `account_code` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `account_code` (`account_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'SEL','Specialised English Language Service','010'),(2,'TCS','Technical & Computer Services','020'),(3,'FA','Finance & Accounting','030'),(4,'MAT','Material','040'),(5,'RC','Resources Centre','050'),(6,'FO','Front Office','060'),(7,'MAR','Marketing','070'),(8,'SEC','Security','080'),(9,'R08','Class Room 8','090');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disposal_details`
--

DROP TABLE IF EXISTS `disposal_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `disposal_details` (
  `id` int(11) NOT NULL auto_increment,
  `disposal_id` varchar(50) NOT NULL,
  `asset_detail_id` int(11) NOT NULL,
  `asset_category_id` int(11) NOT NULL,
  `sales_amount` decimal(20,2) unsigned default '0.00',
  `loss_profit_amount` decimal(20,2) default '0.00',
  `price` decimal(20,2) unsigned default '0.00',
  `book_value` decimal(20,2) unsigned default '0.00',
  `accum_dep` decimal(20,2) unsigned default '0.00',
  `date_of_purchase` date NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `disposal_id` (`disposal_id`),
  KEY `asset_id` (`asset_detail_id`),
  KEY `asset_category_id` (`asset_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `disposal_details`
--

LOCK TABLES `disposal_details` WRITE;
/*!40000 ALTER TABLE `disposal_details` DISABLE KEYS */;
INSERT INTO `disposal_details` VALUES (1,'1',191,6,'800000.00','-4485416.67','5375000.00','5285416.67','89583.33','2011-03-15',''),(2,'1',192,6,'6000000.00','714583.33','5375000.00','5285416.67','89583.33','2011-03-15','');
/*!40000 ALTER TABLE `disposal_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disposal_statuses`
--

DROP TABLE IF EXISTS `disposal_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `disposal_statuses` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `Name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `disposal_statuses`
--

LOCK TABLES `disposal_statuses` WRITE;
/*!40000 ALTER TABLE `disposal_statuses` DISABLE KEYS */;
INSERT INTO `disposal_statuses` VALUES (1,'New'),(2,'Request For Approval'),(3,'Approved by Supervisor'),(4,'Approved by Fincon'),(5,'Reject'),(6,'Finish'),(7,'Journal Posted');
/*!40000 ALTER TABLE `disposal_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disposal_types`
--

DROP TABLE IF EXISTS `disposal_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `disposal_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `disposal_types`
--

LOCK TABLES `disposal_types` WRITE;
/*!40000 ALTER TABLE `disposal_types` DISABLE KEYS */;
INSERT INTO `disposal_types` VALUES (1,'Write Off'),(2,'Sales');
/*!40000 ALTER TABLE `disposal_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disposals`
--

DROP TABLE IF EXISTS `disposals`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `disposals` (
  `id` int(11) NOT NULL auto_increment,
  `doc_date` date NOT NULL,
  `no` varchar(10) NOT NULL,
  `department_id` varchar(20) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `notes` text NOT NULL,
  `disposal_status_id` varchar(50) NOT NULL,
  `disposal_type_id` varchar(50) NOT NULL,
  `reject_notes` text NOT NULL,
  `reject_by` varchar(50) NOT NULL,
  `reject_date` datetime NOT NULL,
  `cancel_notes` text NOT NULL,
  `cancel_by` varchar(50) NOT NULL,
  `cancel_date` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `disposals`
--

LOCK TABLES `disposals` WRITE;
/*!40000 ALTER TABLE `disposals` DISABLE KEYS */;
INSERT INTO `disposals` VALUES (1,'2011-03-18','DIS-0001','1','gs','','3','1','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(2,'2011-03-18','DIS-0002','5','gs','','3','2','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `disposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(20) default NULL,
  `descr` varchar(20) default NULL,
  `auth_amount` decimal(20,0) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'admin','Administrators','0'),(2,'Pimpinan Cabang','','0'),(3,'PO Approval 1','','5000000'),(4,'PO Approval 2','','10000000'),(5,'PO Approval 3','','50000000'),(6,'Normal','','0'),(7,'GS','GS Members','0'),(8,'Fincon Users','','0'),(9,'GS Supervisor','SPV GS','0');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_menus`
--

DROP TABLE IF EXISTS `groups_menus`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `groups_menus` (
  `menu_id` int(10) unsigned NOT NULL default '0',
  `group_id` int(10) unsigned NOT NULL default '0',
  KEY `groups_menus_FKIndex1` (`group_id`),
  KEY `groups_menus_FKIndex2` (`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `groups_menus`
--

LOCK TABLES `groups_menus` WRITE;
/*!40000 ALTER TABLE `groups_menus` DISABLE KEYS */;
INSERT INTO `groups_menus` VALUES (30,1),(29,1),(64,1),(63,1),(62,1),(98,1),(28,1),(148,1),(148,7),(67,7),(147,1),(146,1),(97,1),(96,1),(24,1),(93,1),(3,1),(105,3),(104,3),(73,3),(72,3),(94,7),(24,7),(10,7),(93,7),(9,7),(8,7),(7,7),(92,7),(3,7),(151,7),(150,7),(149,7),(145,7),(144,7),(50,7),(49,7),(58,7),(141,7),(142,7),(117,7),(115,7),(116,7),(114,7),(39,7),(13,7),(110,7),(113,7),(130,7),(129,7),(124,7),(126,7),(125,7),(122,7),(128,7),(127,7),(123,7),(4,7),(143,7),(140,7),(139,7),(138,7),(137,7),(136,7),(132,7),(134,7),(133,7),(131,7),(79,7),(66,7),(38,7),(103,7),(102,7),(101,7),(100,7),(2,7),(81,7),(82,7),(80,7),(109,7),(108,7),(107,7),(106,7),(78,7),(112,7),(111,7),(77,7),(76,7),(75,7),(154,7),(152,7),(105,7),(104,7),(73,7),(74,7),(72,7),(90,7),(89,7),(69,7),(68,7),(50,2),(49,2),(58,2),(141,2),(66,6),(38,6),(109,6),(78,6),(90,6),(105,5),(104,5),(73,5),(74,5),(72,5),(72,4),(74,4),(73,4),(104,4),(105,4),(72,8),(74,8),(73,8),(104,8),(105,8),(75,8),(76,8),(77,8),(111,8),(112,8),(85,8),(86,8),(78,8),(109,8),(80,8),(82,8),(2,8),(100,8),(101,8),(4,8),(123,8),(127,8),(128,8),(122,8),(125,8),(126,8),(124,8),(129,8),(130,8),(113,8),(110,8),(13,8),(39,8),(114,8),(116,8),(115,8),(117,8),(142,8),(141,8),(58,8),(49,8),(50,8),(144,8),(145,8),(149,8),(150,8),(151,8),(3,8),(87,8),(88,8),(99,8),(91,8),(89,6),(69,6),(70,6),(68,6),(142,2),(117,2),(4,6),(123,6),(127,6),(128,6),(113,6),(13,6),(39,6),(114,6),(115,6),(117,6),(142,6),(141,6),(58,6),(115,2),(114,2),(39,2),(13,2),(113,2),(128,2),(127,2),(123,2),(4,2),(109,2),(78,2),(90,2),(89,2),(69,2),(68,2);
/*!40000 ALTER TABLE `groups_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inlog_details`
--

DROP TABLE IF EXISTS `inlog_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `inlog_details` (
  `id` int(11) NOT NULL auto_increment,
  `inlog_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(10) NOT NULL default '1',
  `price` decimal(20,2) NOT NULL default '0.00',
  `amount` decimal(20,2) NOT NULL default '0.00',
  `posting` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `inlog_id` (`inlog_id`,`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `inlog_details`
--

LOCK TABLES `inlog_details` WRITE;
/*!40000 ALTER TABLE `inlog_details` DISABLE KEYS */;
INSERT INTO `inlog_details` VALUES (1,1,9,10,'25000.00','250000.00',1),(2,1,12,15,'40000.00','600000.00',1),(3,2,10,10,'20000.00','200000.00',1),(4,2,11,10,'50000.00','500000.00',1),(5,3,10,15,'25000.00','375000.00',1);
/*!40000 ALTER TABLE `inlog_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inlogs`
--

DROP TABLE IF EXISTS `inlogs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `inlogs` (
  `id` int(11) NOT NULL auto_increment,
  `no` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `supplier_id` (`supplier_id`,`po_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `inlogs`
--

LOCK TABLES `inlogs` WRITE;
/*!40000 ALTER TABLE `inlogs` DISABLE KEYS */;
INSERT INTO `inlogs` VALUES (1,'IN-0001','2011-04-01',8,3,'2011-04-01 17:04:00','gs'),(2,'IN-0002','2011-04-03',2,2,'2011-04-03 09:29:00','gs'),(3,'IN-0003','2011-03-07',3,1,'2011-03-07 11:24:00','gs'),(4,'IN-0004','2011-04-15',2,1,'2011-04-15 13:18:00','cabang');
/*!40000 ALTER TABLE `inlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_ledgers`
--

DROP TABLE IF EXISTS `inventory_ledgers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `inventory_ledgers` (
  `id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(10) NOT NULL default '0',
  `in_out` varchar(50) NOT NULL,
  `price` decimal(20,2) NOT NULL default '0.00',
  `amount` decimal(20,2) NOT NULL default '0.00',
  `doc_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `item_id` (`item_id`,`in_out`,`doc_id`,`po_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `inventory_ledgers`
--

LOCK TABLES `inventory_ledgers` WRITE;
/*!40000 ALTER TABLE `inventory_ledgers` DISABLE KEYS */;
INSERT INTO `inventory_ledgers` VALUES (1,'2011-04-01',9,10,'inlog','25000.00','250000.00',1,3),(2,'2011-04-01',12,15,'inlog','40000.00','600000.00',2,3),(3,'2011-04-02',9,5,'outlog','30000.00','150000.00',1,0),(4,'2011-04-03',10,10,'inlog','20000.00','200000.00',3,2),(5,'2011-04-03',11,10,'inlog','50000.00','500000.00',4,2),(6,'2011-04-03',10,5,'outlog','20000.00','100000.00',2,0),(7,'2011-03-08',10,10,'outlog','35000.00','350000.00',3,0),(8,'2011-03-07',10,15,'inlog','25000.00','375000.00',5,1);
/*!40000 ALTER TABLE `inventory_ledgers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_bank_account_types`
--

DROP TABLE IF EXISTS `invoice_bank_account_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoice_bank_account_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoice_bank_account_types`
--

LOCK TABLES `invoice_bank_account_types` WRITE;
/*!40000 ALTER TABLE `invoice_bank_account_types` DISABLE KEYS */;
INSERT INTO `invoice_bank_account_types` VALUES (1,'Cash','Cash'),(2,'Cheque','Cheque'),(3,'Transfer','Bank Transfer');
/*!40000 ALTER TABLE `invoice_bank_account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_details`
--

DROP TABLE IF EXISTS `invoice_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL auto_increment,
  `invoice_id` int(11) NOT NULL,
  `asset_category_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `color` varchar(10) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL default '0',
  `price` decimal(20,2) NOT NULL default '0.00',
  `price_cur` decimal(20,2) NOT NULL default '0.00',
  `amount` decimal(20,2) NOT NULL,
  `amount_cur` decimal(20,2) NOT NULL,
  `discount` decimal(20,2) NOT NULL default '0.00',
  `discount_cur` decimal(20,2) NOT NULL default '0.00',
  `amount_after_disc` decimal(20,2) NOT NULL,
  `amount_after_disc_cur` decimal(20,2) NOT NULL,
  `vat` decimal(20,2) NOT NULL,
  `vat_cur` decimal(20,2) NOT NULL,
  `wht` decimal(20,2) NOT NULL,
  `wht_cur` decimal(20,2) NOT NULL,
  `amount_nett` decimal(20,2) NOT NULL default '0.00',
  `amount_nett_cur` decimal(20,2) NOT NULL default '0.00',
  `currency_id` int(11) NOT NULL,
  `rp_rate` decimal(20,2) NOT NULL default '1.00',
  `vat_rate` decimal(20,2) NOT NULL,
  `wht_rate` decimal(20,2) NOT NULL,
  `npb_id` int(11) NOT NULL default '0',
  `po_id` int(11) NOT NULL default '0',
  `umurek` int(11) NOT NULL,
  `is_vat` tinyint(1) NOT NULL default '1',
  `is_wht` tinyint(1) NOT NULL default '0',
  `department_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_asset_category` (`asset_category_id`),
  KEY `id_invoice` (`invoice_id`),
  KEY `id_npb` (`npb_id`),
  KEY `id_po` (`po_id`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoice_details`
--

LOCK TABLES `invoice_details` WRITE;
/*!40000 ALTER TABLE `invoice_details` DISABLE KEYS */;
INSERT INTO `invoice_details` VALUES (1,3,8,'K-019-Meja Kerja','','','',10,'500000.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','0.00','0.00','5500000.00','5500000.00',0,'1.00','10.00','2.00',1,1,5,1,0,4),(2,3,6,'K099-Komputer Lengkap 2','','','',20,'4500000.00','4500000.00','90000000.00','90000000.00','0.00','0.00','90000000.00','90000000.00','9000000.00','9000000.00','0.00','0.00','99000000.00','99000000.00',0,'1.00','10.00','2.00',2,1,5,1,0,8),(3,4,6,'K0199-Printer lengkap','','','',20,'450000.00','450000.00','9000000.00','9000000.00','0.00','0.00','9000000.00','9000000.00','900000.00','900000.00','0.00','0.00','9900000.00','9900000.00',0,'1.00','10.00','2.00',2,2,5,1,0,8),(4,4,6,'K0199-Printer lengkap','','','',10,'500000.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','0.00','0.00','5500000.00','5500000.00',0,'1.00','10.00','2.00',4,2,5,1,0,4),(5,4,6,'K0199-Printer lengkap','','','',10,'4000000.00','4000000.00','40000000.00','40000000.00','0.00','0.00','40000000.00','40000000.00','4000000.00','4000000.00','0.00','0.00','44000000.00','44000000.00',0,'1.00','10.00','2.00',5,2,5,1,0,4),(6,5,12,'MD-023-Speaker','','','',11,'50000.00','50000.00','550000.00','550000.00','0.00','0.00','550000.00','550000.00','55000.00','55000.00','0.00','0.00','605000.00','605000.00',1,'1.00','10.00','2.00',4,5,2,1,0,4),(7,6,6,'K099-Komputer Lengkap 2','','','',10,'5600000.00','5600000.00','56000000.00','56000000.00','0.00','0.00','56000000.00','56000000.00','5600000.00','5600000.00','0.00','0.00','61600000.00','61600000.00',0,'1.00','10.00','2.00',12,17,5,1,0,4),(8,6,6,'K0199-Printer lengkap','','','',10,'4500000.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','0.00','0.00','49500000.00','49500000.00',0,'1.00','10.00','2.00',12,17,5,1,0,4),(9,6,6,'K099-Komputer Lengkap 2','','','',5,'5600000.00','5600000.00','28000000.00','28000000.00','0.00','0.00','28000000.00','28000000.00','2800000.00','2800000.00','0.00','0.00','30800000.00','30800000.00',0,'1.00','10.00','2.00',13,17,5,1,0,8);
/*!40000 ALTER TABLE `invoice_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_statuses`
--

DROP TABLE IF EXISTS `invoice_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoice_statuses` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoice_statuses`
--

LOCK TABLES `invoice_statuses` WRITE;
/*!40000 ALTER TABLE `invoice_statuses` DISABLE KEYS */;
INSERT INTO `invoice_statuses` VALUES (1,'New',''),(2,'Unpaid',''),(3,'Paid',''),(4,'Registered to Asset','Registered to Asset'),(5,'Receive Journal Posted',''),(6,'DONE - Payment Journal Posted','');
/*!40000 ALTER TABLE `invoice_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `no` varchar(10) NOT NULL,
  `inv_date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `department_id` int(11) default NULL,
  `currency_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `po_no` varchar(10) NOT NULL,
  `paid_date` date default NULL,
  `paid_bank_name` varchar(200) NOT NULL,
  `paid_bank_account_no` varchar(100) NOT NULL,
  `paid_bank_account_name` varchar(200) NOT NULL,
  `paid_bank_account_type_id` int(11) NOT NULL,
  `convert_asset` tinyint(1) NOT NULL default '0',
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `wht_rate` decimal(10,2) NOT NULL default '0.00',
  `vat_rate` decimal(10,2) NOT NULL default '10.00',
  `sub_total` decimal(20,2) NOT NULL,
  `vat_base` decimal(20,2) NOT NULL default '0.00',
  `wht_base` decimal(20,2) NOT NULL default '0.00',
  `discount` decimal(20,2) NOT NULL,
  `after_disc` decimal(20,2) NOT NULL,
  `wht_total` decimal(20,2) NOT NULL,
  `vat_total` decimal(20,2) NOT NULL,
  `total` decimal(20,2) NOT NULL,
  `billing_address` text NOT NULL,
  `shipping_address` text NOT NULL,
  `status_invoice_id` int(11) NOT NULL default '1',
  `rp_rate` decimal(20,2) NOT NULL,
  `bank_account_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `id_supplier` (`supplier_id`),
  KEY `created` (`created`),
  KEY `id_department` (`department_id`),
  KEY `inv_date` (`inv_date`),
  KEY `status_invoice_id` (`status_invoice_id`),
  KEY `paid_bank_name` (`paid_bank_name`,`paid_bank_account_no`),
  KEY `paid_bank_account_type_id` (`paid_bank_account_type_id`),
  KEY `currency_id` (`currency_id`),
  KEY `paid_bank_account_name` (`paid_bank_account_name`),
  KEY `bank_account_id` (`bank_account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (3,'1','2011-04-25',2,NULL,1,'','',NULL,'','','',0,1,'2011-04-25 06:44:51','2.00','10.00','95000000.00','95000000.00','0.00','0.00','95000000.00','0.00','9500000.00','104500000.00','','',4,'1.00',0),(4,'1122','2011-04-25',1,NULL,1,'','',NULL,'','','',0,1,'2011-04-25 08:29:48','2.00','10.00','54000000.00','54000000.00','0.00','0.00','54000000.00','0.00','5400000.00','59400000.00','','',4,'1.00',0),(5,'11221','2011-04-25',1,NULL,1,'','',NULL,'','','',0,1,'2011-04-25 08:39:06','2.00','10.00','550000.00','550000.00','0.00','0.00','550000.00','0.00','55000.00','605000.00','','',4,'1.00',0),(6,'i21','2011-04-29',8,NULL,1,'','',NULL,'','','',0,1,'2011-04-29 08:21:29','2.00','10.00','129000000.00','129000000.00','0.00','0.00','129000000.00','0.00','12900000.00','141900000.00','','',4,'1.00',0);
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices_journal_transactions`
--

DROP TABLE IF EXISTS `invoices_journal_transactions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoices_journal_transactions` (
  `id` int(11) NOT NULL auto_increment,
  `invoice_id` int(11) NOT NULL,
  `journal_transaction_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `invoice_id` (`invoice_id`,`journal_transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoices_journal_transactions`
--

LOCK TABLES `invoices_journal_transactions` WRITE;
/*!40000 ALTER TABLE `invoices_journal_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices_journal_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices_pos`
--

DROP TABLE IF EXISTS `invoices_pos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoices_pos` (
  `id` int(11) NOT NULL auto_increment,
  `invoice_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `invoice_id` (`invoice_id`,`po_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoices_pos`
--

LOCK TABLES `invoices_pos` WRITE;
/*!40000 ALTER TABLE `invoices_pos` DISABLE KEYS */;
INSERT INTO `invoices_pos` VALUES (4,3,1),(6,4,2),(8,5,5),(10,6,17);
/*!40000 ALTER TABLE `invoices_pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices_purchases`
--

DROP TABLE IF EXISTS `invoices_purchases`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `invoices_purchases` (
  `id` int(11) NOT NULL auto_increment,
  `invoice_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `invoice_id` (`invoice_id`,`purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `invoices_purchases`
--

LOCK TABLES `invoices_purchases` WRITE;
/*!40000 ALTER TABLE `invoices_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `items` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `code` varchar(10) NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` decimal(20,2) NOT NULL,
  `avg_price` decimal(20,2) NOT NULL,
  `descr` tinytext NOT NULL,
  `request_type_id` int(11) NOT NULL,
  `asset_category_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `unit_id` int(11) default NULL,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_asset_category` (`asset_category_id`),
  KEY `id_currency` (`currency_id`),
  KEY `unit_id` (`unit_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'K099','Komputer Lengkap 2','1000.00','0.00','',1,6,2,3,'2011-04-26 06:27:27'),(2,'K0199','Printer lengkap','5000000.00','0.00','',1,6,1,4,'2011-04-26 06:27:55'),(3,'K-010','Kursi','100000.00','0.00','',2,8,1,2,'2011-04-26 06:28:05'),(4,'K-019','Meja Kerja','100000.00','0.00','',2,8,1,3,'2011-04-26 06:28:15'),(5,'LAP001','Laptop','15000000.00','0.00','',1,6,1,2,'2011-04-26 06:28:22'),(6,'LMR001','Lemari Besi','5000000.00','0.00','',2,9,1,4,'2011-04-26 06:28:31'),(8,'K09966','mobil','100000000.00','0.00','',2,5,1,2,'2011-04-26 06:28:39'),(9,'MD-023','Speaker','30.00','0.00','',1,12,2,2,'2011-03-30 10:14:53'),(10,'MD-009','Touch Pad','100000.00','0.00','Test',1,13,1,2,'0000-00-00 00:00:00'),(11,'INV099','kertas','50000.00','0.00','aaa',2,15,1,1,'2011-03-25 09:11:56'),(12,'MOS-012','Mouse','1000000.00','0.00','',1,12,1,3,'0000-00-00 00:00:00'),(13,'GD6546','Gediung','32354.00','0.00','',2,3,1,1,'2011-04-26 06:22:34');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_groups`
--

DROP TABLE IF EXISTS `journal_groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal_groups` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal_groups`
--

LOCK TABLES `journal_groups` WRITE;
/*!40000 ALTER TABLE `journal_groups` DISABLE KEYS */;
INSERT INTO `journal_groups` VALUES (1,'Penerimaan FA'),(2,'Mutasi FA'),(3,'Write Off FA'),(4,'Pembayaran Supplier'),(5,'Penyusutan FA'),(6,'Distribusi FA dari Head Office ke Branch'),(7,'Distribusi FA dari Head Office ke Unit Kerja'),(8,'Penjualan FA');
/*!40000 ALTER TABLE `journal_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_positions`
--

DROP TABLE IF EXISTS `journal_positions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal_positions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal_positions`
--

LOCK TABLES `journal_positions` WRITE;
/*!40000 ALTER TABLE `journal_positions` DISABLE KEYS */;
INSERT INTO `journal_positions` VALUES (1,'Debit'),(2,'Credit');
/*!40000 ALTER TABLE `journal_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_template_details`
--

DROP TABLE IF EXISTS `journal_template_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal_template_details` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `journal_template_id` int(10) unsigned NOT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `journal_position_id` tinyint(3) unsigned NOT NULL,
  `for_destination_branch` tinyint(1) NOT NULL default '0',
  `for_profit_sales` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `journal_template_id` (`journal_template_id`,`account_id`,`journal_position_id`),
  KEY `destination_branch` (`for_destination_branch`),
  KEY `for_profit_sales` (`for_profit_sales`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal_template_details`
--

LOCK TABLES `journal_template_details` WRITE;
/*!40000 ALTER TABLE `journal_template_details` DISABLE KEYS */;
INSERT INTO `journal_template_details` VALUES (6,3,4,1,0,0),(4,2,1,1,0,0),(5,2,59,2,0,0),(7,3,59,2,0,0),(8,4,7,1,0,0),(9,4,59,2,0,0),(13,11,2,2,0,0),(12,11,3,1,0,0),(14,12,6,1,0,0),(15,12,5,2,0,0),(16,15,2,1,0,1),(17,18,59,1,0,0),(18,18,39,2,0,0),(19,5,4,1,0,0),(20,5,59,2,0,0),(23,19,39,2,0,0),(22,19,59,1,0,0),(25,20,39,2,0,0),(26,20,59,1,0,0),(27,26,101,1,0,0),(28,26,100,2,0,0),(29,21,9,1,0,0),(30,21,8,2,0,0),(31,22,6,1,0,0),(32,22,5,2,0,0),(33,27,92,1,0,0),(34,27,21,2,0,0),(35,28,95,1,0,0),(36,28,94,2,0,0),(37,13,100,1,0,0),(38,13,99,2,0,0),(39,30,1,2,0,0),(40,30,103,1,0,0),(41,30,2,1,0,0),(42,30,1,1,1,0),(43,30,102,2,1,0),(44,30,2,2,1,0),(45,33,5,1,0,0),(46,33,103,1,0,0),(47,33,4,2,0,0),(48,33,4,1,1,0),(49,33,102,2,1,0),(50,33,5,2,1,0),(51,9,20,1,0,0),(52,9,59,2,0,0),(53,6,96,1,0,0),(54,6,59,2,0,0),(55,39,59,1,0,0),(56,39,39,2,0,0),(57,40,59,1,0,0),(58,40,39,2,0,0),(59,15,39,1,0,1),(60,15,56,2,0,1),(61,15,1,2,0,1),(62,15,57,1,0,0),(63,16,5,1,0,1),(64,16,39,1,0,1),(65,16,56,2,0,1),(66,16,4,2,0,1),(67,16,5,1,0,0),(68,16,39,1,0,0),(69,16,57,1,0,0),(70,16,4,2,0,0),(71,17,8,1,0,1),(72,17,39,1,0,1),(73,17,56,2,0,1),(74,17,7,2,0,1),(75,17,8,1,0,0),(76,17,39,1,0,0),(77,17,57,1,0,0),(78,17,7,2,0,0),(79,58,5,1,0,1),(80,58,39,1,0,1),(81,58,56,2,0,1),(82,58,4,2,0,1),(83,58,5,1,0,0),(84,58,39,1,0,0),(85,58,57,1,0,0),(86,58,4,2,0,0),(87,62,21,1,0,1),(88,62,39,1,0,1),(89,62,56,2,0,1),(90,62,20,2,0,1),(91,62,21,1,0,0),(92,62,39,1,0,0),(93,62,57,1,0,0),(94,62,20,2,0,0),(95,56,100,1,0,1),(96,56,39,1,0,1),(97,56,56,2,0,1),(98,56,99,2,0,1),(99,56,100,1,0,0),(100,56,39,1,0,0),(101,56,57,1,0,0),(102,56,99,2,0,0),(103,63,94,1,0,1),(104,63,39,1,0,1),(105,63,56,2,0,1),(106,63,93,2,0,1),(107,63,94,1,0,0),(108,63,39,1,0,0),(109,63,57,1,0,0),(110,63,93,2,0,0),(111,45,5,1,0,1),(112,45,104,1,0,1),(113,45,4,2,0,1),(114,25,6,1,0,1),(115,25,5,2,0,1),(116,64,105,1,0,1),(117,64,59,2,0,1),(118,65,59,1,0,1),(119,65,39,2,0,1),(120,35,103,1,0,1),(121,35,5,1,0,1),(122,35,4,2,0,1),(123,35,4,1,1,1),(124,35,5,2,1,1),(125,35,102,2,1,1);
/*!40000 ALTER TABLE `journal_template_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_templates`
--

DROP TABLE IF EXISTS `journal_templates`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal_templates` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `journal_group_id` int(10) unsigned NOT NULL,
  `asset_category_id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `journal_template_id` (`journal_group_id`,`asset_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal_templates`
--

LOCK TABLES `journal_templates` WRITE;
/*!40000 ALTER TABLE `journal_templates` DISABLE KEYS */;
INSERT INTO `journal_templates` VALUES (1,1,1,'Penerimaan FA Tanah'),(2,1,3,'Penerimaan FA Gedung'),(3,1,4,'Penerimaan FA Instalasi'),(4,1,5,'Penerimaan FA Kendaraan'),(5,1,6,'Penerimaan FA Hardware Komputer'),(6,1,7,'Penerimaan FA Peripheral  Komputer'),(7,1,8,'Penerimaan FA Inventaris Gol I'),(8,1,9,'Penerimaan FA Inventaris Gol II'),(9,1,10,'Penerimaan FA Software Komputer'),(10,1,11,'Penerimaan FA Leasehold'),(11,5,3,'Penyusutan Gedung'),(12,5,4,'Penyusutan Instalasi'),(13,2,1,'Mutasi FA Tanah'),(18,4,3,'Pembayaran FA Gedung'),(15,8,3,'Penjualan FA Gedung'),(16,8,4,'Penjualan FA Instalasi'),(17,8,5,'Penjualan FA Kendaraan'),(19,4,6,'Pembayaran FA Hardware Komputer'),(20,4,5,'Pembayaran FA Kendaraan'),(21,5,5,'Penyusutan FA Kendaraan'),(22,5,6,'Penyusutan FA Hardware'),(23,5,8,'Penyusutan FA Inventaris Ktr Gol I'),(24,5,9,'Penyusutan FA Inventaris Ktr Gol II'),(25,5,7,'Penyusutan FA Peripheral Komputer'),(26,5,1,'Penyusutan FA Tanah'),(27,5,10,'Penyusutan FA Software'),(28,5,11,'Penyusutan FA Leasehold'),(29,2,2,'Mutasi Bangunan Dalam Penyelesaian'),(30,2,3,'Mutasi Gedung'),(31,2,4,'Mutasi Instalasi'),(32,2,5,'Mutasi Kendaraan'),(33,2,6,'Mutasi Hardware Komputer'),(34,2,7,'Mutasi Peripheral Komputer'),(35,2,8,'Inventaris Gol I'),(36,2,9,'Inventaris Gol II'),(37,2,10,'Mutasi Software Komputer'),(38,2,11,'Mutasi Leasehold'),(39,4,10,'Pembayaran Software'),(40,4,7,'Pembayaran Peripheral'),(41,3,1,'Write off Land'),(42,3,2,'Write off Building'),(43,3,4,'Write off Installation'),(44,3,5,'Write off Vehicle'),(45,3,6,'Write off Hardware'),(46,3,7,'Write off Peripheral'),(47,3,8,'Write off Inv I'),(48,3,9,'Write off Inv II'),(49,3,10,'Write off Software'),(50,3,11,'Write off Leasehold'),(51,4,11,'Pembayaran Leasehold'),(52,4,1,'Pembayaran Tanah'),(53,4,4,'Pembayaran Instalasi'),(54,4,8,'Pembayaran Inv I'),(55,4,9,'Pembayaran Inv II'),(56,8,1,'Penjualan Tanah'),(58,8,6,'Penjualan Hardware'),(59,8,7,'Penjualan Peripheral'),(60,8,8,'Penjualan Inv I'),(61,8,9,'Penjualan Inv II'),(62,8,10,'Penjualan Software'),(63,8,11,'Penjualan Leasehold'),(64,1,16,'Penerimaan FA Amort'),(65,4,16,'Pembayaran Amortisasi');
/*!40000 ALTER TABLE `journal_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_transactions`
--

DROP TABLE IF EXISTS `journal_transactions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal_transactions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `date` date NOT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `journal_position_id` int(10) unsigned NOT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `amount_db` decimal(20,2) NOT NULL default '0.00',
  `amount_cr` decimal(20,2) NOT NULL default '0.00',
  `posting` tinyint(4) NOT NULL default '0',
  `account_code` varchar(50) NOT NULL,
  `notes` varchar(100) NOT NULL,
  `source` varchar(50) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `journal_template_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `journal_template_detail_id` (`date`,`account_id`,`journal_position_id`,`department_id`,`amount_db`,`posting`,`account_code`),
  KEY `source` (`source`),
  KEY `invoice_id` (`doc_id`),
  KEY `amount_db` (`amount_db`),
  KEY `amount_cr` (`amount_cr`),
  KEY `journal_template_id` (`journal_template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=405 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal_transactions`
--

LOCK TABLES `journal_transactions` WRITE;
/*!40000 ALTER TABLE `journal_transactions` DISABLE KEYS */;
INSERT INTO `journal_transactions` VALUES (1,'2011-02-23',39,2,1,'0.00','10000000.00',0,'010.0010999993','','invoice',17,19),(2,'2011-02-23',59,1,1,'10000000.00','0.00',0,'010.1234567','','invoice',17,19),(3,'2011-02-28',7,1,1,'50000000.00','0.00',0,'010.1080-05','','invoice',21,4),(4,'2011-02-28',59,2,1,'0.00','50000000.00',0,'010.1234567','','invoice',21,4),(5,'2011-02-28',39,2,1,'0.00','50000000.00',0,'010.0010999993','','invoice',21,20),(6,'2011-02-28',59,1,1,'50000000.00','0.00',0,'010.1234567','','invoice',21,20),(7,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(8,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(9,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(10,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(11,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(12,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(13,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(14,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(15,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(16,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(17,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(18,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(19,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',48,22),(20,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',48,22),(21,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(22,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(23,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(24,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(25,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(26,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(27,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(28,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(29,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(30,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(31,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(32,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(33,'2011-02-28',5,2,1,'0.00','166666.67',0,'010.1081-04','','asset',52,22),(34,'2011-02-28',6,1,1,'166666.67','0.00',0,'010.5323-14','','asset',52,22),(35,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(36,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(37,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(38,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(39,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(40,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(41,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(42,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(43,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(44,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(45,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(46,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(47,'2011-02-28',5,2,5,'0.00','166666.67',0,'050.1081-04','','asset',53,22),(48,'2011-02-28',6,1,5,'166666.67','0.00',0,'050.5323-14','','asset',53,22),(49,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(50,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(51,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(52,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(53,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(54,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(55,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(56,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(57,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(58,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(59,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(60,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(61,'2011-02-28',5,2,2,'0.00','333333.33',0,'020.1081-04','','asset',42,22),(62,'2011-02-28',6,1,2,'333333.33','0.00',0,'020.5323-14','','asset',42,22),(63,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(64,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(65,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(66,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(67,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(68,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(69,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(70,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(71,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(72,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(73,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(74,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(75,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',41,22),(76,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',41,22),(77,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(78,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(79,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(80,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(81,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(82,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(83,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(84,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(85,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(86,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(87,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(88,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(89,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',46,22),(90,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',46,22),(91,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(92,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(93,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(94,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(95,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(96,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(97,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(98,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(99,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(100,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(101,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(102,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(103,'2011-02-28',5,2,2,'0.00','166666.67',0,'020.1081-04','','asset',47,22),(104,'2011-02-28',6,1,2,'166666.67','0.00',0,'020.5323-14','','asset',47,22),(105,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(106,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(107,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(108,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(109,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(110,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(111,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(112,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(113,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(114,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(115,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(116,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(117,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',105,22),(118,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',105,22),(119,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(120,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(121,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(122,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(123,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(124,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(125,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(126,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(127,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(128,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(129,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(130,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(131,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',107,22),(132,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',107,22),(133,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(134,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(135,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(136,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(137,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(138,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(139,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(140,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(141,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(142,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(143,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(144,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(145,'2011-02-28',5,2,4,'0.00','166666.67',0,'040.1081-04','','asset',108,12),(146,'2011-02-28',6,1,4,'166666.67','0.00',0,'040.5323-14','','asset',108,12),(147,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(148,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(149,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(150,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(151,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(152,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(153,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(154,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(155,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(156,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(157,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(158,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(159,'2011-02-28',8,2,4,'0.00','33333333.33',0,'040.1081-03','','asset',110,21),(160,'2011-02-28',9,1,4,'33333333.33','0.00',0,'040.5322-14','','asset',110,21),(161,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(162,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(163,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(164,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(165,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(166,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(167,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(168,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(169,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(170,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(171,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(172,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(173,'2011-02-28',2,2,4,'0.00','0.00',0,'040.1081-01','','asset',111,11),(174,'2011-02-28',3,1,4,'0.00','0.00',0,'040.5320-14','','asset',111,11),(175,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(176,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(177,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(178,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(179,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(180,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(181,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(182,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(183,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(184,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(185,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(186,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(187,'2011-02-28',5,2,4,'0.00','1666666.67',0,'040.1081-04','','asset',112,12),(188,'2011-02-28',6,1,4,'1666666.67','0.00',0,'040.5323-14','','asset',112,12),(189,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(190,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(191,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(192,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(193,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(194,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(195,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(196,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(197,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(198,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(199,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(200,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(201,'2011-02-28',5,2,4,'0.00','166666666.67',0,'040.1081-04','','asset',113,12),(202,'2011-02-28',6,1,4,'166666666.67','0.00',0,'040.5323-14','','asset',113,12),(203,'2011-02-28',4,1,1,'5000000.00','0.00',0,'010.1080-06 ','','invoice',20,5),(204,'2011-02-28',59,2,1,'0.00','5000000.00',0,'010.1234567','','invoice',20,5),(205,'2011-02-28',4,1,1,'15000000.00','0.00',0,'010.1080-06 ','','invoice',20,5),(206,'2011-02-28',59,2,1,'0.00','15000000.00',0,'010.1234567','','invoice',20,5),(207,'2011-02-28',4,1,1,'5000000.00','0.00',0,'010.1080-06 ','','invoice',20,5),(208,'2011-02-28',59,2,1,'0.00','5000000.00',0,'010.1234567','','invoice',20,5),(209,'2011-02-28',4,1,1,'15000000.00','0.00',0,'010.1080-06 ','','invoice',20,5),(210,'2011-02-28',59,2,1,'0.00','15000000.00',0,'010.1234567','','invoice',20,5),(211,'2011-03-11',5,1,4,'333333.34','0.00',0,'040.360.1081-04','','movement',1,33),(212,'2011-03-11',103,1,4,'9666666.66','0.00',0,'040.360.030','','movement',1,33),(213,'2011-03-11',4,2,4,'0.00','10000000.00',0,'040.360.1080-06 ','','movement',1,33),(214,'2011-03-11',4,1,3,'10000000.00','0.00',0,'030.360.1080-06 ','','movement',1,33),(215,'2011-03-11',5,2,3,'0.00','333333.34',0,'030.360.1081-04','','movement',1,33),(216,'2011-03-11',102,2,3,'0.00','9666666.66',0,'030.360.040','','movement',1,33),(217,'2011-03-11',20,1,1,'50000000.00','0.00',0,'010.360.1080-10','','invoice',24,9),(218,'2011-03-11',59,2,1,'0.00','50000000.00',0,'010.360.1234567','','invoice',24,9),(219,'2011-03-11',96,1,1,'1000000.00','0.00',0,'010.360.1080-12 ','','invoice',24,6),(220,'2011-03-11',59,2,1,'0.00','1000000.00',0,'010.360.1234567','','invoice',24,6),(221,'2011-03-11',59,1,1,'50000000.00','0.00',0,'010.360.1234567','','invoice',24,39),(222,'2011-03-11',39,2,1,'0.00','50000000.00',0,'010.360.0010999993','','invoice',24,39),(223,'2011-03-11',59,1,1,'1000000.00','0.00',0,'010.360.1234567','','invoice',24,40),(224,'2011-03-11',39,2,1,'0.00','1000000.00',0,'010.360.0010999993','','invoice',24,40),(225,'2011-03-15',4,1,8,'56000000.00','0.00',0,'080.360.1080-06 ','','invoice',12,5),(226,'2011-03-15',59,2,8,'0.00','56000000.00',0,'080.360.1234567','','invoice',12,5),(227,'2011-03-15',4,1,4,'85000000.00','0.00',0,'040.360.1080-06 ','','invoice',12,5),(228,'2011-03-15',59,2,4,'0.00','85000000.00',0,'040.360.1234567','','invoice',12,5),(229,'2011-03-15',4,1,4,'10000000.00','0.00',0,'040.360.1080-06 ','','invoice',12,5),(230,'2011-03-15',59,2,4,'0.00','10000000.00',0,'040.360.1234567','','invoice',12,5),(231,'2011-03-15',59,1,8,'56000000.00','0.00',0,'080.360.1234567','','invoice',12,19),(232,'2011-03-15',39,2,8,'0.00','56000000.00',0,'080.360.0010999993','','invoice',12,19),(233,'2011-03-15',59,1,4,'85000000.00','0.00',0,'040.360.1234567','','invoice',12,19),(234,'2011-03-15',39,2,4,'0.00','85000000.00',0,'040.360.0010999993','','invoice',12,19),(235,'2011-03-15',59,1,4,'10000000.00','0.00',0,'040.360.1234567','','invoice',12,19),(236,'2011-03-15',39,2,4,'0.00','10000000.00',0,'040.360.0010999993','','invoice',12,19),(237,'2011-03-15',4,1,5,'50000000.00','0.00',0,'050.360.1080-06 ','','invoice',13,5),(238,'2011-03-15',59,2,5,'0.00','50000000.00',0,'050.360.1234567','','invoice',13,5),(239,'2011-03-15',59,1,5,'50000000.00','0.00',0,'050.360.1234567','','invoice',13,19),(240,'2011-03-15',39,2,5,'0.00','50000000.00',0,'050.360.0010999993','','invoice',13,19),(241,'2011-03-15',4,1,1,'50000000.00','0.00',0,'010.360.1080-06 ','','invoice',19,5),(242,'2011-03-15',59,2,1,'0.00','50000000.00',0,'010.360.1234567','','invoice',19,5),(243,'2011-03-15',59,1,1,'50000000.00','0.00',0,'010.360.1234567','','invoice',19,19),(244,'2011-03-15',39,2,1,'0.00','50000000.00',0,'010.360.0010999993','','invoice',19,19),(245,'2011-03-15',6,1,1,'895833.33','0.00',0,'010.360.5323-14','','asset',22,22),(246,'2011-03-15',5,2,1,'0.00','895833.33',0,'010.360.1081-04','','asset',22,22),(247,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(248,'2011-03-18',39,1,1,'4000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(249,'2011-03-18',57,1,1,'1285416.67','0.00',0,'010.360.FA00003','','disposal',4,58),(250,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(251,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(252,'2011-03-18',39,1,1,'6000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(253,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(254,'2011-03-18',56,2,1,'0.00','714583.33',0,'010.360.FA00002','','disposal',4,58),(255,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(256,'2011-03-18',39,1,1,'4000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(257,'2011-03-18',57,1,1,'1285416.67','0.00',0,'010.360.FA00003','','disposal',4,58),(258,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(259,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(260,'2011-03-18',39,1,1,'6000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(261,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(262,'2011-03-18',56,2,1,'0.00','714583.33',0,'010.360.FA00002','','disposal',4,58),(263,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(264,'2011-03-18',39,1,1,'4000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(265,'2011-03-18',57,1,1,'1285416.67','0.00',0,'010.360.FA00003','','disposal',4,58),(266,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(267,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(268,'2011-03-18',39,1,1,'6000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(269,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(270,'2011-03-18',56,2,1,'0.00','714583.33',0,'010.360.FA00002','','disposal',4,58),(271,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(272,'2011-03-18',39,1,1,'4000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(273,'2011-03-18',57,1,1,'1285416.67','0.00',0,'010.360.FA00003','','disposal',4,58),(274,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(275,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(276,'2011-03-18',39,1,1,'6000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(277,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(278,'2011-03-18',56,2,1,'0.00','714583.33',0,'010.360.FA00002','','disposal',4,58),(279,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(280,'2011-03-18',39,1,1,'4000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(281,'2011-03-18',57,1,1,'1285416.67','0.00',0,'010.360.FA00003','','disposal',4,58),(282,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(283,'2011-03-18',5,1,1,'89583.33','0.00',0,'010.360.1081-04','','disposal',4,58),(284,'2011-03-18',39,1,1,'6000000.00','0.00',0,'010.360.0010999993','','disposal',4,58),(285,'2011-03-18',4,2,1,'0.00','5375000.00',0,'010.360.1080-06 ','','disposal',4,58),(286,'2011-03-18',56,2,1,'0.00','714583.33',0,'010.360.FA00002','','disposal',4,58),(287,'2011-03-21',4,1,4,'50000000.00','0.00',0,'040.360.1080-06 ','','invoice',20,5),(288,'2011-03-21',59,2,4,'0.00','50000000.00',0,'040.360.1234567','','invoice',20,5),(289,'2011-03-21',4,1,5,'60000000.00','0.00',0,'050.360.1080-06 ','','invoice',20,5),(290,'2011-03-21',59,2,5,'0.00','60000000.00',0,'050.360.1234567','','invoice',20,5),(291,'2011-03-21',59,1,4,'50000000.00','0.00',0,'040.360.1234567','','invoice',20,19),(292,'2011-03-21',39,2,4,'0.00','50000000.00',0,'040.360.0010999993','','invoice',20,19),(293,'2011-03-21',59,1,5,'60000000.00','0.00',0,'050.360.1234567','','invoice',20,19),(294,'2011-03-21',39,2,5,'0.00','60000000.00',0,'050.360.0010999993','','invoice',20,19),(295,'2011-03-21',6,1,4,'891000.00','0.00',0,'040.360.5323-14','','asset',23,22),(296,'2011-03-21',5,2,4,'0.00','891000.00',0,'040.360.1081-04','','asset',23,22),(297,'2011-03-21',59,1,1,'50000000.00','0.00',0,'010.360.1234567','','invoice',19,19),(298,'2011-03-21',39,2,1,'0.00','50000000.00',0,'010.360.0010999993','','invoice',19,19),(299,'2011-03-21',4,1,5,'50000000.00','0.00',0,'050.360.1080-06 ','','invoice',13,5),(300,'2011-03-21',59,2,5,'0.00','50000000.00',0,'050.360.1234567','','invoice',13,5),(301,'2011-03-23',6,1,4,'891000.00','0.00',0,'040.360.5323-14','','asset',1,22),(302,'2011-03-23',5,2,4,'0.00','891000.00',0,'040.360.1081-04','','asset',1,22),(303,'2011-03-23',6,1,5,'980000.00','0.00',0,'050.360.5323-14','','asset',2,22),(304,'2011-03-23',5,2,5,'0.00','980000.00',0,'050.360.1081-04','','asset',2,22),(305,'2011-03-23',6,1,1,'895833.33','0.00',0,'010.360.5323-14','','asset',3,22),(306,'2011-03-23',5,2,1,'0.00','895833.33',0,'010.360.1081-04','','asset',3,22),(307,'2011-03-25',5,1,4,'89100.00','0.00',0,'040.360.1081-04','','movement',7,33),(308,'2011-03-25',103,1,4,'5256900.00','0.00',0,'040.360.080','','movement',7,33),(309,'2011-03-25',4,2,4,'0.00','5346000.00',0,'040.360.1080-06 ','','movement',7,33),(310,'2011-03-25',5,1,4,'89100.00','0.00',0,'040.360.1081-04','','movement',8,33),(311,'2011-03-25',103,1,4,'5256900.00','0.00',0,'040.360.080','','movement',8,33),(312,'2011-03-25',4,2,4,'0.00','5346000.00',0,'040.360.1080-06 ','','movement',8,33),(313,'2011-03-25',4,1,8,'5346000.00','0.00',0,'080.360.1080-06 ','','movement',8,33),(314,'2011-03-25',5,2,8,'0.00','89100.00',0,'080.360.1081-04','','movement',8,33),(315,'2011-03-25',102,2,8,'0.00','5256900.00',0,'080.360.040','','movement',8,33),(316,'2011-03-25',5,1,4,'89100.00','0.00',0,'040.360.1081-04','','movement',7,33),(317,'2011-03-25',103,1,4,'5256900.00','0.00',0,'040.360.080','','movement',7,33),(318,'2011-03-25',4,2,4,'0.00','5346000.00',0,'040.360.1080-06 ','','movement',7,33),(319,'2011-03-25',5,1,4,'89100.00','0.00',0,'040.360.1081-04','','movement',8,33),(320,'2011-03-25',103,1,4,'5256900.00','0.00',0,'040.360.080','','movement',8,33),(321,'2011-03-25',4,2,4,'0.00','5346000.00',0,'040.360.1080-06 ','','movement',8,33),(322,'2011-03-25',4,1,8,'5346000.00','0.00',0,'080.360.1080-06 ','','movement',8,33),(323,'2011-03-25',5,2,8,'0.00','89100.00',0,'080.360.1081-04','','movement',8,33),(324,'2011-03-25',102,2,8,'0.00','5256900.00',0,'080.360.040','','movement',8,33),(325,'2011-03-25',5,1,4,'89100.00','0.00',0,'040.360.1081-04','','movement',7,33),(326,'2011-03-25',103,1,4,'5256900.00','0.00',0,'040.360.080','','movement',7,33),(327,'2011-03-25',4,2,4,'0.00','5346000.00',0,'040.360.1080-06 ','','movement',7,33),(328,'2011-03-25',5,1,4,'89100.00','0.00',0,'040.360.1081-04','','movement',8,33),(329,'2011-03-25',103,1,4,'5256900.00','0.00',0,'040.360.080','','movement',8,33),(330,'2011-03-25',4,2,4,'0.00','5346000.00',0,'040.360.1080-06 ','','movement',8,33),(331,'2011-03-25',4,1,8,'5346000.00','0.00',0,'080.360.1080-06 ','','movement',8,33),(332,'2011-03-25',5,2,8,'0.00','89100.00',0,'080.360.1081-04','','movement',8,33),(333,'2011-03-25',102,2,8,'0.00','5256900.00',0,'080.360.040','','movement',8,33),(334,'2011-03-29',9,1,3,'3333333.33','0.00',0,'030.360.5322-14','','asset',9,21),(335,'2011-03-29',8,2,3,'0.00','3333333.33',0,'030.360.1081-03','','asset',9,21),(336,'2011-03-29',6,1,6,'170000.00','0.00',0,'060.360.5323-14','','asset',12,25),(337,'2011-03-29',5,2,6,'0.00','170000.00',0,'060.360.1081-04','','asset',12,25),(338,'2011-04-05',105,1,6,'560000000.00','0.00',0,'060.360.2222','','invoice',22,64),(339,'2011-04-05',59,2,6,'0.00','560000000.00',0,'060.360.1234567','','invoice',22,64),(340,'2011-04-05',59,1,6,'560000000.00','0.00',0,'060.360.1234567','','invoice',22,65),(341,'2011-04-05',39,2,6,'0.00','560000000.00',0,'060.360.0010999993','','invoice',22,65),(342,'2011-04-05',105,1,4,'8000000.00','0.00',0,'040.360.2222','','invoice',24,64),(343,'2011-04-05',59,2,4,'0.00','8000000.00',0,'040.360.1234567','','invoice',24,64),(344,'2011-04-05',59,1,4,'8000000.00','0.00',0,'040.360.1234567','','invoice',24,65),(345,'2011-04-05',39,2,4,'0.00','8000000.00',0,'040.360.0010999993','','invoice',24,65),(346,'2011-04-05',105,1,1,'100000000.00','0.00',0,'010.360.2222','','invoice',23,64),(347,'2011-04-05',59,2,1,'0.00','100000000.00',0,'010.360.1234567','','invoice',23,64),(348,'2011-04-05',59,1,1,'100000000.00','0.00',0,'010.360.1234567','','invoice',23,65),(349,'2011-04-05',39,2,1,'0.00','100000000.00',0,'010.360.0010999993','','invoice',23,65),(350,'2011-04-05',59,1,1,'100000000.00','0.00',0,'010.360.1234567','','invoice',23,65),(351,'2011-04-05',39,2,1,'0.00','100000000.00',0,'010.360.0010999993','','invoice',23,65),(352,'2011-04-05',59,1,1,'100000000.00','0.00',0,'010.360.1234567','','invoice',23,65),(353,'2011-04-05',39,2,1,'0.00','100000000.00',0,'010.360.0010999993','','invoice',23,65),(354,'2011-04-05',59,1,1,'100000000.00','0.00',0,'010.360.1234567','','invoice',23,65),(355,'2011-04-05',39,2,1,'0.00','100000000.00',0,'010.360.0010999993','','invoice',23,65),(356,'2011-04-05',59,1,1,'100000000.00','0.00',0,'010.360.1234567','','invoice',23,65),(357,'2011-04-05',39,2,1,'0.00','100000000.00',0,'010.360.0010999993','','invoice',23,65),(358,'2011-04-05',105,1,6,'560000000.00','0.00',0,'060.360.2222','','invoice',22,64),(359,'2011-04-05',59,2,6,'0.00','560000000.00',0,'060.360.1234567','','invoice',22,64),(360,'2011-04-05',59,1,6,'560000000.00','0.00',0,'060.360.1234567','','invoice',22,65),(361,'2011-04-05',39,2,6,'0.00','560000000.00',0,'060.360.0010999993','','invoice',22,65),(362,'2011-04-11',4,1,4,'45000000.00','0.00',0,'040.360.1080-06 ','','invoice',25,5),(363,'2011-04-11',59,2,4,'0.00','45000000.00',0,'040.360.1234567','','invoice',25,5),(364,'2011-04-11',59,1,4,'45000000.00','0.00',0,'040.360.1234567','','invoice',25,19),(365,'2011-04-11',39,2,4,'0.00','45000000.00',0,'040.360.0010999993','','invoice',25,19),(366,'2011-04-13',6,1,4,'825000.00','0.00',0,'040.360.5323-14','','asset',26,22),(367,'2011-04-13',5,2,4,'0.00','825000.00',0,'040.360.1081-04','','asset',26,22),(368,'2011-04-13',101,1,4,'22916.67','0.00',0,'040.360.5327-14 ','','asset',27,26),(369,'2011-04-13',100,2,4,'0.00','22916.67',0,'040.360.1081-08 ','','asset',27,26),(370,'2011-04-18',4,1,4,'455000.00','0.00',0,'040.360.1080-06 ','','invoice',29,5),(371,'2011-04-18',59,2,4,'0.00','455000.00',0,'040.360.1234567','','invoice',29,5),(372,'2011-04-18',7,1,4,'56000000.00','0.00',0,'040.360.1080-05','','invoice',29,4),(373,'2011-04-18',59,2,4,'0.00','56000000.00',0,'040.360.1234567','','invoice',29,4),(374,'2011-04-18',4,1,4,'45000.00','0.00',0,'040.360.1080-06 ','','invoice',29,3),(375,'2011-04-18',59,2,4,'0.00','45000.00',0,'040.360.1234567','','invoice',29,3),(376,'2011-04-21',4,1,4,'1000000.00','0.00',0,'040.360.1080-06 ','','invoice',32,5),(377,'2011-04-21',59,2,4,'0.00','1000000.00',0,'040.360.1234567','','invoice',32,5),(378,'2011-04-21',59,1,4,'1000000.00','0.00',0,'040.360.1234567','','invoice',32,19),(379,'2011-04-21',39,2,4,'0.00','1000000.00',0,'040.360.0010999993','','invoice',32,19),(380,'2011-04-21',4,1,1,'5000000.00','0.00',0,'010.360.1080-06 ','','invoice',34,5),(381,'2011-04-21',59,2,1,'0.00','5000000.00',0,'010.360.1234567','','invoice',34,5),(382,'2011-04-21',1,1,1,'4000000.00','0.00',0,'010.360.1080-03','','invoice',34,2),(383,'2011-04-21',59,2,1,'0.00','4000000.00',0,'010.360.1234567','','invoice',34,2),(384,'2011-04-21',96,1,1,'150000000.00','0.00',0,'010.360.1080-12 ','','invoice',34,6),(385,'2011-04-21',59,2,1,'0.00','150000000.00',0,'010.360.1234567','','invoice',34,6),(386,'2011-04-21',20,1,1,'50000000.00','0.00',0,'010.360.1080-10','','invoice',34,9),(387,'2011-04-21',59,2,1,'0.00','50000000.00',0,'010.360.1234567','','invoice',34,9),(388,'2011-04-21',59,1,1,'5000000.00','0.00',0,'010.360.1234567','','invoice',34,19),(389,'2011-04-21',39,2,1,'0.00','5000000.00',0,'010.360.0010999993','','invoice',34,19),(390,'2011-04-21',59,1,1,'4000000.00','0.00',0,'010.360.1234567','','invoice',34,18),(391,'2011-04-21',39,2,1,'0.00','4000000.00',0,'010.360.0010999993','','invoice',34,18),(392,'2011-04-21',59,1,1,'150000000.00','0.00',0,'010.360.1234567','','invoice',34,40),(393,'2011-04-21',39,2,1,'0.00','150000000.00',0,'010.360.0010999993','','invoice',34,40),(394,'2011-04-21',59,1,1,'50000000.00','0.00',0,'010.360.1234567','','invoice',34,39),(395,'2011-04-21',39,2,1,'0.00','50000000.00',0,'010.360.0010999993','','invoice',34,39),(396,'2011-04-25',5,1,4,'0.00','0.00',0,'040.360.1081-04','','movement',9,35),(397,'2011-04-25',103,1,4,'0.00','0.00',0,'040.360.090','','movement',9,35),(398,'2011-04-25',4,2,4,'0.00','550000.00',0,'040.360.1080-06 ','','movement',9,35),(399,'2011-04-25',5,1,4,'0.00','0.00',0,'040.360.1081-04','','movement',10,35),(400,'2011-04-25',103,1,4,'0.00','0.00',0,'040.360.090','','movement',10,35),(401,'2011-04-25',4,2,4,'0.00','550000.00',0,'040.360.1080-06 ','','movement',10,35),(402,'2011-04-25',4,1,9,'550000.00','0.00',0,'090.360.1080-06 ','','movement',10,35),(403,'2011-04-25',5,2,9,'0.00','0.00',0,'090.360.1081-04','','movement',10,35),(404,'2011-04-25',102,2,9,'0.00','0.00',0,'090.360.040','','movement',10,35);
/*!40000 ALTER TABLE `journal_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL auto_increment,
  `code` char(3) NOT NULL,
  `name` char(40) default NULL,
  `department_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `department_id` (`department_id`,`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'SEL','RUANG SELS',1,0),(2,'R1','CLASSROOM 1',5,0),(3,'MNG','RUANG MANAGER',0,0),(4,'GUD','GUDANG UTAMA',0,0),(5,'RC','Resources Centre',0,0),(6,'','KASIR',5,0);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned default NULL,
  `title` varchar(50) default NULL,
  `url` varchar(100) default NULL,
  `help` varchar(50) default NULL,
  `urutan` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `urutan` (`urutan`)
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (75,NULL,'Invoice','#','',20),(2,78,'Disposal','','',20),(3,NULL,'Master Data','#','',200),(4,NULL,'Reports','#','',100),(24,3,'Asset Item Category','/asset_categories','',110),(7,3,'Warranty','/warranties','',70),(8,3,'Departement','/departments','',80),(9,3,'Requesters','/requesters','',90),(10,3,'Locations','/locations','',100),(117,113,'Depreciation Recap','/asset_details/reports/rekap','',110),(13,113,'Monthly Depreciation Report','/assets/reports/depr','',10),(78,NULL,'Fixed Assets','#','',40),(74,72,'New PO','/pos/add','',NULL),(81,80,'New Movement','/movements/add','',30),(28,NULL,'Sys Admin','#','',500),(29,28,'Backup Database','/admins/backup','',60),(30,28,'Restote Database','/admins/restore','',70),(77,75,'List Invoice','/invoices/index','',20),(103,2,'New Disposal Sales','/disposals/add/2','',94),(69,68,'List MR','/npbs/index','',1),(70,68,'Add New MR','/npbs/add','',0),(72,NULL,'PO','#','',10),(73,72,'List PO','/pos/index','',NULL),(68,NULL,'MR','#','',0),(38,78,'Labelling','/asset_details/label','',185),(39,113,'Monthly Detail Depreciation Report','/asset_details/reports/depr','',20),(115,113,'Transfer Report','/movements/reports/fa','',90),(102,2,'New Disposal Write Off','/disposals/add/1','',84),(145,144,'Stock Movement Report','/inventory_ledgers/movement_report','',235),(80,78,'Movement','#','',10),(49,4,'Supplier History','/suppliers/history','',200),(50,4,'Warranty History','/warranties/history','',210),(82,80,'List Movements','/movements/index','',25),(79,NULL,'Stock','#','',60),(111,75,'Outstanding Report','/invoices/report/outstanding','',30),(112,75,'Finish Report','/invoices/report/finish','',40),(113,4,'Fixed Assets','#','',40),(114,113,'Detail Report','/asset_details/reports/detail_fa','',50),(58,4,'Find Asset','/assets/find','',197),(76,75,'New Invoice','/invoices/add','',10),(62,28,'User Management','/users','',52),(63,28,'Menus Management','/menus','',53),(64,28,'Group & Permission Management','/groups','',54),(66,78,'Physical Check','/asset_details/check','',186),(67,3,'Currency Rate','finance-currency.php',NULL,112),(85,NULL,'Journal','#','',30),(86,85,'List Journal Transaction','/journal_transactions','',NULL),(87,3,'GL Journal','','',10),(88,87,'Templates','/journal_templates/index','',10),(89,68,'Outstanding Report','/npbs/npb_report/outstanding','',50),(90,68,'Finish Report','/npbs/npb_report/finish','',60),(101,2,'List Disposal Sales','/disposals/index/2','',79),(100,2,'List Disposal Write Off','/disposals/index/1','',67),(91,3,'GL Accounts','/accounts','',20),(92,3,'Supplier','/suppliers','',30),(93,3,'Currency','/currencies','',100),(94,3,'Items','/items','',110),(96,3,'NPB Status','/npb_statuses','',130),(97,3,'PO Status','/po_statuses','',140),(98,28,'System Configuration','/configs','',10),(99,87,'Journal Group','/journal_groups','',20),(116,113,' Purchase Report','/purchases/reports/fa','',70),(104,72,'Outstanding Report','/pos/po_report/outstanding','',30),(105,72,'Finish Report','/pos/po_report/finish','',40),(106,78,'Register','#','',0),(107,106,'New FA Register','/purchases/add','',10),(108,106,'List FA Register','/purchases','',20),(109,78,'List Assets','/assets/','',10),(110,113,'Process Depreciation','/assets/process_depr','',0),(144,4,'Stock','#','',230),(143,138,'Stock Status','#','',393),(142,113,'Montly Depreciation Recap','/asset_details/reports/monthly_rekap','',120),(141,113,'Movement Report','/asset_details/reports/movement','',200),(122,4,'PO','#','',20),(123,4,'NPB','#','',10),(124,4,'Invoice','#','',30),(125,122,'Outstanding Report','/pos/po_report/outstanding','',10),(126,122,'Finish Report','/pos/po_report/finish','',20),(127,123,'Outstanding Report','/npbs/npb_report/outstanding','',10),(128,123,'Finish Report','/npbs/npb_report/finish','',20),(129,124,'Outstanding Report','/invoices/report/outstanding','',10),(130,124,'Finish Report','/invoices/report/finish','',20),(131,79,'Stock Inlog','#','',447),(132,79,'Stock Outlog','#','',451),(133,131,'New Stock Inlog','/inlogs/add','',353),(134,131,'List Stock Inlog','/inlogs/index','',359),(136,132,'New Stock Outlog','/outlogs/add','',366),(137,132,'List Stock Outlog','/outlogs/index','',373),(138,79,'Stock Ledger','#','',456),(139,138,'Procces Stock Ledger','/inventory_ledgers/process_inv','',384),(140,138,'Stock List','/inventory_ledgers/index','',389),(152,3,'Category Type','/asset_category_types','',177),(146,3,'Movement Status','/movement_statuses','',150),(147,3,'Disposal Status','/disposal_statuses','',160),(148,3,'Unit Item','/units','',170),(149,144,'Stock Report','/inventory_ledgers/stock_report','',241),(150,144,'Stock Inlog Report','/inventory_ledgers/in_recap_report','',242),(151,144,'Stock Outlog Report','/inventory_ledgers/out_recap_report','',243),(154,72,'List DO','/delivery_orders/list_delivery_order','',100);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movement_details`
--

DROP TABLE IF EXISTS `movement_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `movement_details` (
  `id` int(11) NOT NULL auto_increment,
  `movement_id` int(11) NOT NULL,
  `asset_category_id` int(11) NOT NULL,
  `asset_detail_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `date_of_purchase` date NOT NULL,
  `notes` text NOT NULL,
  `price` decimal(20,2) NOT NULL,
  `book_value` decimal(20,2) NOT NULL,
  `accum_dep` decimal(20,2) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `movement_id` (`movement_id`,`asset_detail_id`),
  KEY `asset_category_id` (`asset_category_id`),
  KEY `date_of_purchase` (`date_of_purchase`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `movement_details`
--

LOCK TABLES `movement_details` WRITE;
/*!40000 ALTER TABLE `movement_details` DISABLE KEYS */;
INSERT INTO `movement_details` VALUES (1,2,6,1,'6-2011-1-001','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(2,2,6,2,'6-2011-1-002','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(3,2,6,3,'6-2011-1-003','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(4,1,6,8,'6-2011-1-008','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(5,1,6,9,'6-2011-1-009','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(6,1,6,10,'6-2011-1-010','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(7,3,6,1,'6-2011-1-001','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(8,3,6,2,'6-2011-1-002','Komputer Lengkap 2','2011-03-21','','5346000.00','5256900.00','89100.00'),(9,6,8,1,'8-2011-1-001','K-019-Meja Kerja','2011-04-25','','550000.00','0.00','0.00'),(10,6,8,2,'8-2011-1-002','K-019-Meja Kerja','2011-04-25','','550000.00','0.00','0.00'),(11,7,6,56,'6-2011-3-006','K0199-Printer lengkap','2011-04-25','','550000.00','0.00','0.00'),(12,7,6,57,'6-2011-3-007','K0199-Printer lengkap','2011-04-25','','550000.00','0.00','0.00'),(13,8,8,3,'8-2011-1-003','K-019-Meja Kerja','2011-04-25','','550000.00','0.00','0.00'),(14,8,8,4,'8-2011-1-004','K-019-Meja Kerja','2011-04-25','','550000.00','0.00','0.00'),(15,8,8,5,'8-2011-1-005','K-019-Meja Kerja','2011-04-25','','550000.00','0.00','0.00'),(16,10,8,1,'8-2011-1-001-transfe','K-019-Meja Kerja','2011-04-25','','550000.00','0.00','0.00');
/*!40000 ALTER TABLE `movement_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movement_statuses`
--

DROP TABLE IF EXISTS `movement_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `movement_statuses` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `movement_statuses`
--

LOCK TABLES `movement_statuses` WRITE;
/*!40000 ALTER TABLE `movement_statuses` DISABLE KEYS */;
INSERT INTO `movement_statuses` VALUES (1,'New'),(2,'Request For Approval'),(3,'Approved by Supervisor'),(4,'Approved by Fincon'),(5,'Reject'),(6,'Finish'),(7,'Journal Posted');
/*!40000 ALTER TABLE `movement_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movements`
--

DROP TABLE IF EXISTS `movements`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `movements` (
  `id` int(11) NOT NULL auto_increment,
  `doc_date` date NOT NULL,
  `no` varchar(10) NOT NULL,
  `source_department_id` char(40) NOT NULL,
  `dest_department_id` char(40) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `notes` text NOT NULL,
  `movement_status_id` varchar(40) NOT NULL,
  `posting` tinyint(1) NOT NULL,
  `reject_notes` text NOT NULL,
  `reject_by` varchar(50) NOT NULL,
  `reject_date` datetime NOT NULL,
  `cancel_notes` text NOT NULL,
  `cancel_by` varchar(50) NOT NULL,
  `cancel_date` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `doc_date` (`doc_date`,`created_by`,`movement_status_id`),
  KEY `posting` (`posting`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `movements`
--

LOCK TABLES `movements` WRITE;
/*!40000 ALTER TABLE `movements` DISABLE KEYS */;
INSERT INTO `movements` VALUES (1,'2011-03-23','MOV-0001','4','8','gs','','1',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(2,'2011-03-22','MOV-0002','4','2','gs','test notest','2',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(3,'2011-03-25','MOV-0003','4','8','gs','','6',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(4,'0000-00-00','','','','','','6',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(5,'2011-04-21','MOV-0004','4','2','gs','','1',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(6,'2011-04-25','MOV-0005','4','9','gs','','6',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(7,'2011-04-25','MOV-0006','4','6','gs','','6',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(8,'2011-04-26','MOV-0007','4','1','gs','','6',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(9,'2011-04-29','MOV-0008','4','2','gs','','1',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(10,'2011-04-29','MOV-0009','4','5','gs','','1',0,'','','0000-00-00 00:00:00','','','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mutations`
--

DROP TABLE IF EXISTS `mutations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mutations` (
  `id` varchar(8) NOT NULL default '',
  `id_asset_detail` varchar(40) default NULL,
  `id_location` char(3) default NULL,
  `id_department` char(3) default NULL,
  `id_location_baru` char(3) default NULL,
  `id_department_baru` char(3) default NULL,
  `doc_date` date default NULL,
  `alasan` text,
  `serial_no` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `mutations_FKIndex1` (`id_asset_detail`),
  KEY `mutations_FKIndex2` (`id_department`),
  KEY `mutations_FKIndex3` (`id_location`),
  KEY `mutations_FKIndex4` (`id_location_baru`),
  KEY `mutations_FKIndex5` (`id_department_baru`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mutations`
--

LOCK TABLES `mutations` WRITE;
/*!40000 ALTER TABLE `mutations` DISABLE KEYS */;
/*!40000 ALTER TABLE `mutations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `tanggal` datetime default NULL,
  `subject` varchar(100) default NULL,
  `isi` text,
  `submit_by` varchar(10) default NULL,
  PRIMARY KEY  (`id`),
  KEY `news_FKIndex1` (`submit_by`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npb_details`
--

DROP TABLE IF EXISTS `npb_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `npb_details` (
  `id` int(11) NOT NULL auto_increment,
  `npb_id` int(11) NOT NULL,
  `po_id` int(11) default NULL,
  `movement_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `fulfillment_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL default '1',
  `price` decimal(20,2) NOT NULL default '0.00',
  `price_cur` decimal(20,0) NOT NULL default '0',
  `amount` decimal(20,2) NOT NULL default '0.00',
  `amount_cur` decimal(20,2) NOT NULL default '0.00',
  `currency_id` int(11) NOT NULL,
  `rp_rate` decimal(20,2) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `discount` decimal(20,2) NOT NULL default '0.00',
  `discount_cur` decimal(20,2) NOT NULL default '0.00',
  `amount_net` decimal(20,2) NOT NULL default '0.00',
  `amount_net_cur` decimal(20,2) NOT NULL default '0.00',
  `date_finish` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_npb` (`npb_id`,`item_id`,`currency_id`),
  KEY `id_po` (`po_id`),
  KEY `fulfillment_id` (`fulfillment_id`),
  KEY `movement_id` (`movement_id`),
  KEY `date_finish` (`date_finish`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `npb_details`
--

LOCK TABLES `npb_details` WRITE;
/*!40000 ALTER TABLE `npb_details` DISABLE KEYS */;
INSERT INTO `npb_details` VALUES (1,1,4,0,3,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(2,1,1,0,4,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(3,2,1,0,1,0,20,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(4,2,2,0,2,0,20,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(5,4,2,0,2,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(6,4,5,0,9,0,11,'0.00','0','0.00','0.00',1,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(7,5,2,0,2,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(8,6,NULL,0,3,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(9,7,NULL,0,9,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(10,12,17,0,1,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(11,12,17,0,2,0,10,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00'),(12,13,17,0,1,0,5,'0.00','0','0.00','0.00',0,'0.00','','0.00','0.00','0.00','0.00','0000-00-00');
/*!40000 ALTER TABLE `npb_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npb_fulfillments`
--

DROP TABLE IF EXISTS `npb_fulfillments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `npb_fulfillments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `descr` tinytext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `npb_fulfillments`
--

LOCK TABLES `npb_fulfillments` WRITE;
/*!40000 ALTER TABLE `npb_fulfillments` DISABLE KEYS */;
INSERT INTO `npb_fulfillments` VALUES (1,'Procurement','0'),(2,'Movement','0');
/*!40000 ALTER TABLE `npb_fulfillments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npb_statuses`
--

DROP TABLE IF EXISTS `npb_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `npb_statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `npb_statuses`
--

LOCK TABLES `npb_statuses` WRITE;
/*!40000 ALTER TABLE `npb_statuses` DISABLE KEYS */;
INSERT INTO `npb_statuses` VALUES (1,'Draft'),(2,'Approved by Branch Head'),(3,'Sent to Branch Head'),(4,'Reject');
/*!40000 ALTER TABLE `npb_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npb_suppliers`
--

DROP TABLE IF EXISTS `npb_suppliers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `npb_suppliers` (
  `id` int(11) NOT NULL auto_increment,
  `npb_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `selected` int(11) NOT NULL default '0',
  `description` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_npb` (`npb_id`,`supplier_id`),
  KEY `selected` (`selected`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `npb_suppliers`
--

LOCK TABLES `npb_suppliers` WRITE;
/*!40000 ALTER TABLE `npb_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `npb_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npbs`
--

DROP TABLE IF EXISTS `npbs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `npbs` (
  `id` int(11) NOT NULL auto_increment,
  `no` varchar(20) NOT NULL,
  `npb_date` date NOT NULL,
  `department_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL default '0',
  `req_date` date NOT NULL,
  `npb_status_id` int(11) NOT NULL,
  `request_type_id` int(11) NOT NULL,
  `notes` text NOT NULL,
  `created_by` varchar(10) NOT NULL,
  `created_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `reject_notes` text NOT NULL,
  `reject_by` varchar(50) NOT NULL,
  `reject_date` datetime NOT NULL,
  `cancel_notes` text NOT NULL,
  `cancel_by` varchar(50) NOT NULL,
  `cancel_date` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_department` (`department_id`,`req_date`,`npb_status_id`,`created_by`,`created_date`),
  KEY `id_supplier` (`supplier_id`),
  KEY `reject_by` (`reject_by`,`reject_date`),
  KEY `npb_type_id` (`request_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `npbs`
--

LOCK TABLES `npbs` WRITE;
/*!40000 ALTER TABLE `npbs` DISABLE KEYS */;
INSERT INTO `npbs` VALUES (1,'MR-0001','2011-04-25',4,0,'2011-04-25',2,1,'','cabang','2011-04-25 06:25:47','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(2,'MR-0002','2011-04-25',8,0,'2011-04-25',2,1,'','security','2011-04-25 06:27:16','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(4,'MR-MAT-11-0001','2011-04-25',4,0,'2011-04-25',2,1,'','cabang','2011-04-25 08:06:06','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(5,'MR-MAT-11-0002','2011-04-25',4,0,'2011-04-25',2,1,'','cabang','2011-04-25 08:06:12','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(6,'MR-SEC-11-0003','2011-04-25',8,0,'2011-04-25',3,2,'','security','2011-04-25 08:03:10','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(7,'MR-SEC-11-0004','2011-04-25',8,0,'2011-04-25',3,1,'','security','2011-04-25 08:03:38','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(8,'MR-0001','2011-04-27',4,0,'2011-04-27',1,1,'','cabang','2011-04-27 07:08:44','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(9,'MR-0001','2011-04-28',4,0,'2011-04-28',2,1,'','cabang','2011-04-29 03:15:05','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(10,'MR-0001','2011-04-28',4,0,'2011-04-28',2,1,'','cabang','2011-04-29 03:29:53','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(11,'MR-MAT-11-0002','2011-04-29',4,0,'2011-04-29',1,1,'','cabang','2011-04-29 02:27:58','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(12,'MR-MAT-11-0003','2011-04-29',4,0,'2011-04-29',2,1,'','cabang','2011-04-29 07:20:53','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00'),(13,'MR-SEC-11-0005','2011-04-29',8,0,'2011-04-29',2,1,'','security','2011-04-29 07:58:37','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `npbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npbs_pos`
--

DROP TABLE IF EXISTS `npbs_pos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `npbs_pos` (
  `id` int(11) NOT NULL auto_increment,
  `npb_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `npbs.id` (`npb_id`,`po_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `npbs_pos`
--

LOCK TABLES `npbs_pos` WRITE;
/*!40000 ALTER TABLE `npbs_pos` DISABLE KEYS */;
INSERT INTO `npbs_pos` VALUES (4,2,1),(3,1,1),(10,5,2),(9,4,2),(8,2,2),(18,4,5),(16,1,4),(21,12,17),(22,13,17);
/*!40000 ALTER TABLE `npbs_pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outlog_details`
--

DROP TABLE IF EXISTS `outlog_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `outlog_details` (
  `id` int(11) NOT NULL auto_increment,
  `outlog_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(10) NOT NULL default '1',
  `price` decimal(20,2) NOT NULL default '0.00',
  `amount` decimal(20,2) NOT NULL default '0.00',
  `posting` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `outlog_id` (`outlog_id`,`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `outlog_details`
--

LOCK TABLES `outlog_details` WRITE;
/*!40000 ALTER TABLE `outlog_details` DISABLE KEYS */;
INSERT INTO `outlog_details` VALUES (1,1,9,5,'30000.00','150000.00',1),(2,2,10,5,'20000.00','100000.00',1),(3,3,10,10,'35000.00','350000.00',1);
/*!40000 ALTER TABLE `outlog_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outlogs`
--

DROP TABLE IF EXISTS `outlogs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `outlogs` (
  `id` int(11) NOT NULL auto_increment,
  `no` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `department_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `outlogs`
--

LOCK TABLES `outlogs` WRITE;
/*!40000 ALTER TABLE `outlogs` DISABLE KEYS */;
INSERT INTO `outlogs` VALUES (1,'OUT-0001','2011-04-02',6,'2011-04-02 17:06:00','gs'),(2,'OUT-0002','2011-04-03',4,'2011-04-03 09:30:00','gs'),(3,'OUT-0003','2011-03-08',2,'2011-03-08 11:21:00','gs');
/*!40000 ALTER TABLE `outlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pajak`
--

DROP TABLE IF EXISTS `pajak`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pajak` (
  `kelas` char(2) NOT NULL default '',
  `tarif` decimal(10,2) default NULL,
  PRIMARY KEY  (`kelas`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pajak`
--

LOCK TABLES `pajak` WRITE;
/*!40000 ALTER TABLE `pajak` DISABLE KEYS */;
/*!40000 ALTER TABLE `pajak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periode`
--

DROP TABLE IF EXISTS `periode`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `periode` (
  `tgawal` date NOT NULL default '0000-00-00',
  `tgakhir` date NOT NULL default '0000-00-00',
  `bulan` int(10) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `periode`
--

LOCK TABLES `periode` WRITE;
/*!40000 ALTER TABLE `periode` DISABLE KEYS */;
INSERT INTO `periode` VALUES ('2005-06-01','0000-00-00',6);
/*!40000 ALTER TABLE `periode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `po_details`
--

DROP TABLE IF EXISTS `po_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `po_details` (
  `id` int(11) NOT NULL auto_increment,
  `po_id` int(11) NOT NULL,
  `asset_category_id` varchar(29) NOT NULL,
  `name` varchar(40) NOT NULL,
  `color` varchar(10) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL default '0',
  `qty_received` int(11) NOT NULL default '0',
  `price` decimal(20,2) NOT NULL default '0.00',
  `price_cur` decimal(20,2) NOT NULL default '0.00',
  `amount` decimal(20,2) NOT NULL,
  `amount_cur` decimal(20,2) NOT NULL,
  `discount` decimal(20,2) NOT NULL default '0.00',
  `discount_cur` decimal(20,2) NOT NULL default '0.00',
  `amount_after_disc` decimal(20,2) NOT NULL,
  `amount_after_disc_cur` decimal(20,2) NOT NULL,
  `vat` decimal(20,2) NOT NULL,
  `vat_cur` decimal(20,2) NOT NULL,
  `amount_nett` decimal(20,2) NOT NULL default '0.00',
  `amount_nett_cur` decimal(20,2) NOT NULL default '0.00',
  `currency_id` int(11) NOT NULL,
  `rp_rate` decimal(20,2) NOT NULL default '1.00',
  `npb_id` int(11) NOT NULL,
  `umurek` int(11) NOT NULL,
  `is_vat` tinyint(1) NOT NULL default '1',
  `is_wht` tinyint(1) NOT NULL default '0',
  `department_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_asset_category` (`asset_category_id`),
  KEY `id_invoice` (`po_id`),
  KEY `id_npb` (`npb_id`),
  KEY `is_ppn` (`is_vat`,`is_wht`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `po_details`
--

LOCK TABLES `po_details` WRITE;
/*!40000 ALTER TABLE `po_details` DISABLE KEYS */;
INSERT INTO `po_details` VALUES (2,1,'8','K-019-Meja Kerja','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',0,'0.00',1,5,1,0,4),(3,1,'6','K099-Komputer Lengkap 2','','','',20,20,'0.00','4500000.00','90000000.00','90000000.00','0.00','0.00','90000000.00','90000000.00','9000000.00','9000000.00','99000000.00','99000000.00',0,'0.00',2,5,1,0,8),(4,2,'6','K0199-Printer lengkap','','','',20,20,'0.00','500000.00','10000000.00','10000000.00','0.00','0.00','10000000.00','10000000.00','1000000.00','1000000.00','11000000.00','11000000.00',1,'0.00',2,5,1,0,8),(5,2,'6','K0199-Printer lengkap','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',1,'0.00',4,5,1,0,4),(7,2,'6','K0199-Printer lengkap','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',1,'0.00',5,5,1,0,4),(1,4,'8','K-010-Kursi','','','',10,0,'0.00','67000.00','670000.00','670000.00','60000.00','60000.00','610000.00','610000.00','61000.00','61000.00','671000.00','671000.00',0,'0.00',1,5,1,0,4),(6,5,'12','MD-023-Speaker','','','',11,11,'0.00','50000.00','550000.00','550000.00','0.00','0.00','550000.00','550000.00','55000.00','55000.00','605000.00','605000.00',1,'0.00',4,2,1,0,4),(14,8,'6','K0199-Printer lengkap','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',1,'1.00',0,0,1,0,4),(15,8,'6','K0199-Printer lengkap','','','',20,20,'0.00','500000.00','10000000.00','10000000.00','0.00','0.00','10000000.00','10000000.00','1000000.00','1000000.00','11000000.00','11000000.00',1,'1.00',0,0,1,0,4),(16,8,'6','K0199-Printer lengkap','','','',10,10,'0.00','500000.00','5000000.00','5000000.00','0.00','0.00','5000000.00','5000000.00','500000.00','500000.00','5500000.00','5500000.00',1,'1.00',0,0,1,0,4),(17,8,'8','K-019-Meja Kerja ','','','',10,10,'0.00','50000.00','500000.00','500000.00','0.00','0.00','500000.00','500000.00','50000.00','50000.00','550000.00','550000.00',1,'1.00',0,0,1,0,4),(18,8,'5','K09966-mobil','','','',50,50,'0.00','5000000.00','250000000.00','250000000.00','0.00','0.00','250000000.00','250000000.00','25000000.00','25000000.00','275000000.00','275000000.00',1,'1.00',0,0,1,0,4),(13,7,'8','K-010-Kursi','','','',10,0,'0.00','50000.00','500000.00','500000.00','0.00','0.00','500000.00','500000.00','0.00','0.00','500000.00','500000.00',0,'1.00',0,0,1,0,4),(19,8,'5','K09966-mobil','','','',10,10,'0.00','5000000.00','50000000.00','50000000.00','0.00','0.00','50000000.00','50000000.00','5000000.00','5000000.00','55000000.00','55000000.00',1,'1.00',0,0,1,0,4),(10,17,'6','K099-Komputer Lengkap 2','','','',10,10,'0.00','5600000.00','56000000.00','56000000.00','0.00','0.00','56000000.00','56000000.00','5600000.00','5600000.00','61600000.00','61600000.00',0,'0.00',12,5,1,0,4),(11,17,'6','K0199-Printer lengkap','','','',10,10,'0.00','4500000.00','45000000.00','45000000.00','0.00','0.00','45000000.00','45000000.00','4500000.00','4500000.00','49500000.00','49500000.00',0,'0.00',12,5,1,0,4),(12,17,'6','K099-Komputer Lengkap 2','','','',5,5,'0.00','5600000.00','28000000.00','28000000.00','0.00','0.00','28000000.00','28000000.00','2800000.00','2800000.00','30800000.00','30800000.00',0,'0.00',13,5,1,0,8);
/*!40000 ALTER TABLE `po_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `po_payments`
--

DROP TABLE IF EXISTS `po_payments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `po_payments` (
  `id` int(11) NOT NULL auto_increment,
  `po_id` int(11) NOT NULL,
  `term_no` int(11) NOT NULL,
  `term_percent` decimal(10,2) NOT NULL,
  `date_due` date NOT NULL,
  `date_paid` date NOT NULL,
  `amount_due` decimal(20,2) NOT NULL,
  `amount_paid` decimal(20,2) NOT NULL,
  `description` tinytext NOT NULL,
  `amount_po` decimal(20,2) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `po_id` (`po_id`,`term_no`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `po_payments`
--

LOCK TABLES `po_payments` WRITE;
/*!40000 ALTER TABLE `po_payments` DISABLE KEYS */;
INSERT INTO `po_payments` VALUES (2,1,1,'100.00','2010-02-01','0000-00-00','104500000.00','0.00','PO term 1','0.00'),(4,2,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(6,3,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(8,4,1,'100.00','0000-00-00','0000-00-00','671000.00','0.00','PO term 1','0.00'),(10,5,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(12,6,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(14,7,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(16,8,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(18,9,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(20,10,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(22,11,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(24,12,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(26,13,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(28,14,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(30,15,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(33,16,1,'0.00','0000-00-00','0000-00-00','0.00','0.00','PO term 1','0.00'),(35,17,1,'100.00','0000-00-00','0000-00-00','141900000.00','0.00','PO term 1','0.00');
/*!40000 ALTER TABLE `po_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `po_statuses`
--

DROP TABLE IF EXISTS `po_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `po_statuses` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `sorter` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `po_statuses`
--

LOCK TABLES `po_statuses` WRITE;
/*!40000 ALTER TABLE `po_statuses` DISABLE KEYS */;
INSERT INTO `po_statuses` VALUES (1,'Draft',0),(3,'Approved Level 1',0),(4,'Approved Level 2',0),(5,'Approved Level 3',0),(6,'Finish',0),(2,'Request for Approval',0),(7,'Sent',0),(8,'Reject',0);
/*!40000 ALTER TABLE `po_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos`
--

DROP TABLE IF EXISTS `pos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pos` (
  `id` int(11) NOT NULL auto_increment,
  `no` varchar(10) NOT NULL,
  `po_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `department_id` int(11) default NULL,
  `po_status_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `convert_invoice` int(11) NOT NULL default '0',
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `approval_info` text NOT NULL,
  `wht_rate` decimal(10,2) NOT NULL default '0.00',
  `vat_rate` decimal(10,2) NOT NULL default '10.00',
  `vat_base` decimal(20,2) NOT NULL default '0.00',
  `vat_base_cur` decimal(20,2) NOT NULL,
  `wht_base` decimal(20,2) NOT NULL default '0.00',
  `wht_base_cur` decimal(20,2) NOT NULL,
  `sub_total` decimal(20,2) NOT NULL,
  `sub_total_cur` decimal(20,2) NOT NULL,
  `discount` decimal(20,2) NOT NULL default '0.00',
  `discount_cur` decimal(20,2) NOT NULL,
  `after_disc` decimal(20,2) NOT NULL,
  `after_disc_cur` decimal(20,2) NOT NULL,
  `wht_total` decimal(20,2) NOT NULL default '0.00',
  `wht_total_cur` decimal(20,2) NOT NULL,
  `vat_total` decimal(20,2) NOT NULL default '0.00',
  `vat_total_cur` decimal(20,2) NOT NULL,
  `total` decimal(20,2) NOT NULL default '0.00',
  `total_cur` decimal(20,2) NOT NULL,
  `billing_address` text NOT NULL,
  `shipping_address` text NOT NULL,
  `reject_notes` text NOT NULL,
  `reject_by` varchar(50) NOT NULL,
  `reject_date` datetime NOT NULL,
  `cancel_notes` text NOT NULL,
  `cancel_by` varchar(50) NOT NULL,
  `cancel_date` datetime NOT NULL,
  `payment_term` int(11) NOT NULL default '0',
  `rp_rate` decimal(20,2) NOT NULL,
  `date_finish` date NOT NULL,
  `printed` int(11) default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `id_supplier` (`supplier_id`),
  KEY `created` (`created`),
  KEY `id_department` (`department_id`),
  KEY `po_status_id` (`po_status_id`),
  KEY `delivery_date` (`delivery_date`),
  KEY `po_date` (`po_date`),
  KEY `reject_by` (`reject_by`),
  KEY `currency_id` (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pos`
--

LOCK TABLES `pos` WRITE;
/*!40000 ALTER TABLE `pos` DISABLE KEYS */;
INSERT INTO `pos` VALUES (1,'PO-0001','2011-04-25','2011-04-25',2,NULL,7,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','2011-04-25 13:40:14:Approved by:gs','0.00','10.00','95000000.00','95000000.00','0.00','0.00','95000000.00','95000000.00','0.00','0.00','95000000.00','95000000.00','0.00','0.00','9500000.00','9500000.00','104500000.00','104500000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(2,'PO-0002','2011-04-25','2011-04-25',1,NULL,6,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','2011-04-25 15:23:49:Approved by:gs','0.00','10.00','20000000.00','20000000.00','0.00','0.00','20000000.00','20000000.00','0.00','0.00','20000000.00','20000000.00','0.00','0.00','2000000.00','2000000.00','22000000.00','22000000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',5),(4,'PO-0003','2011-04-25','2011-04-25',1,NULL,7,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','2011-04-25 16:09:58:Approved by:gs','0.00','10.00','610000.00','610000.00','0.00','0.00','670000.00','670000.00','60000.00','60000.00','610000.00','610000.00','0.00','0.00','61000.00','61000.00','671000.00','671000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(5,'PO-0004','2011-04-25','2011-04-25',1,NULL,7,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','2011-04-25 15:36:59:Approved by:gs','0.00','10.00','550000.00','550000.00','0.00','0.00','550000.00','550000.00','0.00','0.00','550000.00','550000.00','0.00','0.00','55000.00','55000.00','605000.00','605000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(7,'PO-0005','2011-04-27','2011-04-27',1,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','500000.00','500000.00','0.00','0.00','500000.00','500000.00','0.00','0.00','0.00','0.00','500000.00','500000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(8,'PO-0006','2011-04-27','2011-04-27',1,NULL,6,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','2011-04-27 10:43:01:Approved by:gs','0.00','10.00','320500000.00','320500000.00','0.00','0.00','320500000.00','320500000.00','0.00','0.00','320500000.00','320500000.00','0.00','0.00','32050000.00','32050000.00','352550000.00','352550000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',3),(9,'PO-0007','2011-04-27','2011-04-27',1,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(10,'PO-0008','2011-04-27','2011-04-27',1,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(11,'PO-0009','2011-04-27','2011-04-27',1,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(12,'PO-0010','2011-04-27','2011-04-27',3,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(13,'PO-0011','2011-04-28','2011-04-28',1,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(14,'PO-0012','2011-04-28','2011-04-28',8,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(15,'PO-0013','2011-04-28','2011-04-28',8,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(16,'PO-0014','2011-04-28','2011-04-28',15,NULL,1,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','','0.00','10.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',0),(17,'PO-0015','2011-04-29','2011-04-29',8,NULL,7,1,'bla bla bla hfdsfhdskjhfskjfdshfj fh dsjfhksdhfkjdshdsfsF ',0,'0000-00-00 00:00:00','2011-04-29 15:03:17:Approved by:gs','0.00','10.00','129000000.00','129000000.00','0.00','0.00','129000000.00','129000000.00','0.00','0.00','129000000.00','129000000.00','0.00','0.00','12900000.00','12900000.00','141900000.00','141900000.00','Rabobank,\r\nJl Rasuna Said','Rabobank, \r\nJl Rasuna Said','','','0000-00-00 00:00:00','','','0000-00-00 00:00:00',1,'0.00','0000-00-00',1);
/*!40000 ALTER TABLE `pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `purchases` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `no` varchar(15) NOT NULL default '',
  `doc_no` varchar(10) NOT NULL,
  `warranty_id` int(11) NOT NULL,
  `requester_id` int(11) NOT NULL,
  `department_id` int(11) default NULL,
  `supplier_id` int(11) NOT NULL,
  `invoice_no` varchar(15) default NULL,
  `po_no` varchar(15) default NULL,
  `periode` date default NULL,
  `serial_no` varchar(20) default NULL,
  `voucher_no` varchar(15) NOT NULL default '',
  `sup_tanggal` date NOT NULL default '0000-00-00',
  `sup_vendor_no` varchar(15) default NULL,
  `warranty_card` varchar(20) default NULL,
  `pos_ting` char(1) NOT NULL default 'N',
  `date_of_purchase` date NOT NULL default '0000-00-00',
  `warranty_date` date NOT NULL default '0000-00-00',
  `kd_luar_tanggal` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `beli_FKIndex4` (`warranty_id`),
  KEY `beli_FKIndex6` (`requester_id`),
  KEY `beli_FKIndex7` (`supplier_id`),
  KEY `beli_FKIndex1` (`department_id`),
  KEY `doc_no` (`doc_no`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,'FA-0014','',1,1,0,1,'INV-009','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-02-09','0000-00-00','0000-00-00'),(2,'FA-0002','',0,0,0,5,'','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-02-10','0000-00-00','0000-00-00'),(3,'FA-0012','',0,0,5,1,'SUP-001','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-02-10','0000-00-00','0000-00-00'),(19,'FA-0095','',1,1,0,1,'IN-MK-004','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-03-15','0000-00-00','0000-00-00'),(20,'FA-0094','',1,1,0,6,'IN-DM-001','PO-0004 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-03-21','0000-00-00','0000-00-00'),(12,'FA-0075','',1,1,0,1,'IN-MK-001','PO-0001 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-03-15','0000-00-00','0000-00-00'),(13,'FA-0074','',1,1,0,13,'IN-DE-001','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-03-15','0000-00-00','0000-00-00'),(23,'FA-0104','',1,1,0,1,'INY437','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(22,'FA-0103','',1,1,0,4,'IN0912','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(24,'FA-0107','',1,1,0,1,'IN09124','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(25,'FA-0108','',1,1,0,1,'IN09124','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(26,'FA-0109','',1,1,0,1,'IN09124','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(27,'FA-0110','',1,1,0,4,'IN0912','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(28,'FA-0111','',1,1,0,1,'INY437','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-05','0000-00-00','0000-00-00'),(29,'FA-0112','',1,1,0,1,'IN-MU-009','PO-0007 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-11','0000-00-00','0000-00-00'),(30,'FA-0113','',2,1,5,21,'','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-15','0000-00-00','0000-00-00'),(31,'FA-0114','',1,1,0,1,'INV-1293','PO-0010 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-18','0000-00-00','0000-00-00'),(32,'FA-0115','',1,1,0,1,'INV-1293','PO-0010 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-18','0000-00-00','0000-00-00'),(33,'FA-0116','',1,1,0,1,'INV-1293','PO-0010 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-18','0000-00-00','0000-00-00'),(34,'FA-0117','',1,1,0,1,'INV-1293','PO-0010 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-18','0000-00-00','0000-00-00'),(35,'FA-0118','',1,1,0,1,'IN09479','PO-0013 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-18','0000-00-00','0000-00-00'),(36,'FA-0119','',2,0,0,5,'','www',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-21','0000-00-00','0000-00-00'),(37,'FA-0120','',1,1,1,1,'11','PO-0016 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-21','0000-00-00','0000-00-00'),(38,'FA-0121','',1,1,1,2,'1','PO-0001 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-25','0000-00-00','0000-00-00'),(39,'FA-0122','',1,1,1,1,'1122','PO-0002 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-25','0000-00-00','0000-00-00'),(40,'FA-0123','',1,1,1,1,'11221','PO-0004 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-25','0000-00-00','0000-00-00'),(43,'FA-0126','',1,1,1,8,'i21','PO-0015 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-29','0000-00-00','0000-00-00'),(42,'FA-0125','',5,0,NULL,16,'','',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-29','0000-00-00','0000-00-00'),(46,'FA-0127','',1,1,1,8,'i21','PO-0015 ',NULL,NULL,'','0000-00-00',NULL,NULL,'N','2011-04-29','0000-00-00','0000-00-00');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request_types`
--

DROP TABLE IF EXISTS `request_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `request_types` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `descr` tinytext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `request_types`
--

LOCK TABLES `request_types` WRITE;
/*!40000 ALTER TABLE `request_types` DISABLE KEYS */;
INSERT INTO `request_types` VALUES (1,'IT Items',''),(2,'General Items','');
/*!40000 ALTER TABLE `request_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requesters`
--

DROP TABLE IF EXISTS `requesters`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `requesters` (
  `id` int(10) unsigned NOT NULL,
  `code` char(6) NOT NULL,
  `name` char(40) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `requesters`
--

LOCK TABLES `requesters` WRITE;
/*!40000 ALTER TABLE `requesters` DISABLE KEYS */;
INSERT INTO `requesters` VALUES (1,'R001','Ronny'),(2,'F001','Fendy'),(3,'H001','Hendro'),(4,'S051','Swastika I Wayan'),(5,'T001','Titin Safitri');
/*!40000 ALTER TABLE `requesters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saldoawal`
--

DROP TABLE IF EXISTS `saldoawal`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `saldoawal` (
  `doc_no` varchar(10) NOT NULL default '0',
  `tanggal` date default NULL,
  `periode` date default NULL,
  `tutup` char(1) default NULL,
  `invoice_no` varchar(10) default NULL,
  PRIMARY KEY  (`doc_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `saldoawal`
--

LOCK TABLES `saldoawal` WRITE;
/*!40000 ALTER TABLE `saldoawal` DISABLE KEYS */;
/*!40000 ALTER TABLE `saldoawal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `service` (
  `kode` varchar(10) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `no` varchar(4) NOT NULL default '',
  `name` varchar(40) default NULL,
  `address` varchar(200) default NULL,
  `city` varchar(40) default NULL,
  `telephone` varchar(20) default NULL,
  `email` varchar(50) default NULL,
  `fax` varchar(20) default NULL,
  `hp` varchar(20) default NULL,
  `business_type` varchar(20) default NULL,
  `contact_person` varchar(100) default NULL,
  `province` varchar(50) default NULL,
  `website` varchar(100) default NULL,
  `default_wht_rate` decimal(10,2) NOT NULL default '2.50',
  `bank_name` varchar(50) NOT NULL,
  `bank_account_no` varchar(50) NOT NULL,
  `bank_account_name` varchar(200) NOT NULL,
  `bank_account_type_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `no` (`no`),
  KEY `bank_name` (`bank_name`,`bank_account_no`,`bank_account_name`),
  KEY `bank_account_type_id` (`bank_account_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'P001','PD Multi Kencana','Jl. Pinangsia Raya 81B','Jakarta - citi','022 - 6911606','test@yahoo.com','022 - 4534231','+625 876 545 654','','-','Jakarta','www.test.com','2.00','BCA','47875834','Ujang Sanusi',1),(2,'S001','Shure Electronik','Glodok Baru Blok D 11/8','Jakarta Barat','-','test@yahoo.com','','+625 876 545 654','','ooo','Jakarta','','2.00','BNI','432758909','Shure Electronis',1),(3,'A001','Audio Graha Electronindo','Glodok Plaza Blok H No.6 Jl.Pinangsia N','Jakarta','6280232','Audio@Graha Electronindo.com','021-6280232','0812203654','','123456','Jakarta','www.Graha Electronindo','2.00','','','',0),(4,'M001','MRZ Computer','Komplek Ruko Bahan Bangunan Blok F 2','Jakarta','6296800','test@yahoo.com','','+625 876 545 654','','llll','Jakarta','','2.00','Rabobank','47328782','MRZ Computer PT',3),(5,'Z001','No Name (Glodok)','Glodok','Jakarta','021-236548','aaa@aaa.com','021236548','082222222',NULL,'aaa','Jakarta','www.Glodok.ectronindo','2.00','','','',0),(6,'D001','Dunia Meubel','Jl. KH Hasyim Ashari No.99 B','Jakarta','6313880','-','-',NULL,NULL,'Dewi',NULL,NULL,'2.00','','','',0),(7,'R001','Rizky Jaya','Jl. K.H Hasyim Ashari no. 62','Jakarta Pusat','6331564','-','6331564',NULL,NULL,'-',NULL,NULL,'2.00','','','',0),(8,'P002','PD Donati Inti Karya','Jl. Cideng Barat No. 10A','Jakarta','450000000','daniel@gpsTrackingIndonesia.com','-','0849385','','-','dki','','2.00','','','',0),(9,'G001','Geoff Forrester Indonesia, PT','NHB Building, level 2 Jl. Melawai Raya','Jakarta 12160','7206335/4080','www.gfcom.biz','7244303',NULL,NULL,'Inggriyani Wahyuni',NULL,NULL,'2.00','','','',0),(10,'L001','Lambda Guna Tehnik','Jl. Harapan Jaya Raya No.3 Cempaka Baru','Jakarta Pusat 10640','4247444','-','4223393',NULL,NULL,'Robindra',NULL,NULL,'2.00','','','',0),(11,'B001','Bali Surya Tech','Jl.Nakula no.99 Seminyak','Kuta - Bali','0361-7424081','-','0361-7424081',NULL,NULL,'Agus',NULL,NULL,'2.00','','','',0),(12,'S002','Surya Indah Dewata,CV','Kompleks Sudirman Agung Blok F 14-15','Denpasar','0361-241144,241145','-','0361-241148',NULL,NULL,'Drs.EC.Simon Dutjiadi',NULL,NULL,'2.00','','','',0),(13,'D002','Desain Eko','JL.Bima 17 Pengosekan PO BOX 46','Ubud,Bali','0361-974670','designeko@indo.net.id','0361-974670',NULL,NULL,'Eko Prabowo',NULL,NULL,'2.00','','','',0),(14,'R003','Radja Gorden','JL.Merpati VI/52 Monang Maning JL.Raya','Denpasar, Tuban- Bali','0361-481417','-','-',NULL,NULL,'H Sulaeman',NULL,NULL,'2.00','','','',0),(15,'B002','Bali PasifikStar Redjeki','JL.Dr Sutomo no 105 Denpasar JL.manyar','Bali, Surabaya','0361-420247,031-5950','pasired@yahoo.com','0361-420247,031-5946',NULL,NULL,'Yanti,Arif Rohman',NULL,NULL,'2.00','','','',0),(16,'M002','Muda Jaya','JL.Gajah Mada no 56 Denpasar','Bali','0361-222887,223528,7','-','0361-224297',NULL,NULL,'Ceny Sungkono',NULL,NULL,'2.00','','','',0),(17,'G002','Gelora Perkasa','JL.Teuku Umar no 32 Denpasar','Bali','0361-239777','-','0361-239780',NULL,NULL,'Hans Wira Prayogo',NULL,NULL,'2.00','','','',0),(18,'A002','Audio Multi','JL. Kiara Asri 98','Bandung','022-2546598',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.00','','','',0),(19,'G005','General Utama','jl Gudang utara 908','Bandung','022-4201546','-','022-4201546','-',NULL,'ada','Jawa Barat','-','2.00','','','',0),(20,'Y001','Yayasan Bina Sehat','Jl. Kuningan 787','Bandung','022-250252','Yayasan@BinaSehat.org','022-250252','081252555','','agus','Jawa Barat','www.ayasan Bina Sehat.com','2.00','','','',0),(21,'Y002','Noname','-','Bandung','-','-','-','-',NULL,'-','-','-','2.00','','','',0),(22,'Y003','Yuasa','Jl Yuasa','-','-',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.00','','','',0),(23,'S005','JAKARTA','JAKARTA','JAKARTA','021-2505573','jkt@jkt.com','021-2505573','0812254645',NULL,'ktj','JAKARTA','www.JAKARTA.co.id','2.00','','','',0),(24,'S006','g','g','g','g','g','g','g',NULL,'g','g','g','2.00','','','',0),(25,'S008','BDG','BDG','BDG','BDG','BDG','BDG','BDG',NULL,'BDG','BDG','BDG','2.00','','','',0),(26,'S007','MAS','jalan Mas','MAS','022054','dasd','5','455',NULL,'dd','MAS','da','2.00','','','',0),(27,'F050','Fendy & Fio','Jakarta','Jakarta','-','-','-','-',NULL,'Fendy','DKI','-','2.00','','','',0);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `units` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'rim'),(2,'pcs'),(3,'box'),(4,'dozen');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `department_id` int(3) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'admin','admin@admin.com','21232f297a57a5a743894a0e4a801fc3','Admin',1,1),(3,'heri','admin@admin.com','6812af90c6a1bbec134e323d7e70587b','heri',2,4),(4,'ade','admin@admin.com','a562cfa07c2b1213b3a5c99b756fc206','ade',3,3),(5,'badu','admin@admin.com','40a3de3b98856879b19943f7e93a0375','badu',4,3),(7,'gs','admin@admin.com','1d8d5e912302108b5e88c3e77fcad378','gs user',7,5),(8,'cabang','admin@admin.com','f74e4339be40ffd3b2a263873e653be4','cabang',6,4),(9,'fincon','admin@admin.com','766a69946883ddc09289ac08e256e4b0','sample fincon user',8,5),(10,'spv','gs.spv@admin.com','f4984324c6673ce07aafac15600af26e','supervisor',9,1),(11,'security','security@email.com','e91e6348157868de9dd8b25c81aebfb9','security',6,8),(12,'securityhd','securityhd@email.com','dc0548ea7d843066bfdacf21ce7e1c4d','securityhd',2,8);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `group_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `users_groups_FKIndex1` (`user_id`),
  KEY `users_groups_FKIndex2` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (1,0,1),(2,0,1),(3,0,1);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warranties`
--

DROP TABLE IF EXISTS `warranties`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `warranties` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `code` varchar(4) NOT NULL,
  `name` varchar(40) default NULL,
  `address` varchar(40) default NULL,
  `city` varchar(40) default NULL,
  `telephone` varchar(20) default NULL,
  `email` varchar(50) default NULL,
  `fax` varchar(20) default NULL,
  `hp` varchar(20) default NULL,
  `business_type` varchar(20) default NULL,
  `contact_person` varchar(40) default NULL,
  `province` varchar(50) default NULL,
  `website` varchar(50) default NULL,
  `tanggal` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `warranties`
--

LOCK TABLES `warranties` WRITE;
/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
INSERT INTO `warranties` VALUES (1,'Z002','spart','kjh','jakarta','021-236548','spart@spart.com','021-236548','0812154655','','ttt','jakarta','www.spart.id','2011-01-13'),(2,'Z001','No Warranty','tdk jelas','Bandung','021-2564896','aaa@aaa.com','021236548','0812203654',NULL,'qwqw','Bandung','www.No Warranty',NULL),(3,'Q000','Quantum','ruko segitiga mas','Bandung','022-241569','Q@yh.nok','022-241569','08226565656',NULL,'queri','Bandung','www.Quantum.id',NULL),(4,'BST','Bali Surya Tech','Jl. Nakula 99 Seminyak - Kuta','Kuta','0361-7424081','BST@Bali Surya Tech.com','0361-7424081','085824516',NULL,'i gd','Bali','www.Bali Surya Tech',NULL),(5,'D012','MINOLTA','JL. Panglima Besar Sudirman','Denpasar,Bali','0361-241144,241145','-','0361-241148',NULL,NULL,'Drs.EC.Simon Dutjiadi',NULL,NULL,NULL),(6,'D004','Yusaku','Jl. Komp, Kuning','Bandung','-',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'G001','Gagak','jl gagak 89','Bandung','022-2506548','aaa@aaa.com','022-2506548','081565498','','gagan','Jawabarat','-','2011-01-20');
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-04-29 10:21:57
